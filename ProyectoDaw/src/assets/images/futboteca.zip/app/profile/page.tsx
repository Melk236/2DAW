import Image from "next/image"
import Link from "next/link"
import { Heart, MessageSquare, Eye, Settings, UserPlus, Users } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Profile() {
  return (
    <>
      <Navbar />
      <main style={{ paddingTop: "6rem", paddingBottom: "4rem" }} className="container mx-auto px-4">
        {/* Profile Header */}
        <div className="relative mb-8">
          {/* Cover Image */}
          <div className="h-48 md:h-64 rounded-lg overflow-hidden">
            <Image
              src="/placeholder.svg?height=256&width=1024"
              alt="Cover"
              width={1024}
              height={256}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Profile Info */}
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-end -mt-16 md:-mt-20 relative z-10 px-4">
            {/* Avatar */}
            <div className="w-32 h-32 rounded-full border-4 overflow-hidden" style={{ borderColor: "#14100c" }}>
              <Image
                src="/placeholder.svg?height=128&width=128"
                alt="Avatar"
                width={128}
                height={128}
                className="w-full h-full object-cover"
              />
            </div>

            {/* User Info */}
            <div className="flex-1">
              <h1 className="text-2xl font-bold" style={{ color: "#e8e0d0" }}>
                FutbolHistórico
              </h1>
              <p style={{ color: "rgba(232, 224, 208, 0.7)" }}>Compartiendo los mejores momentos del fútbol mundial</p>

              <div className="flex flex-wrap gap-4 mt-2">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" style={{ color: "#e8e0d0" }} />
                  <span className="text-sm" style={{ color: "#e8e0d0" }}>
                    15.2k seguidores
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" style={{ color: "#e8e0d0" }} />
                  <span className="text-sm" style={{ color: "#e8e0d0" }}>
                    245 siguiendo
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="h-4 w-4" style={{ color: "#e8e0d0" }} />
                  <span className="text-sm" style={{ color: "#e8e0d0" }}>
                    2.5M vistas
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 mt-4 md:mt-0">
              <button className="btn-primary">
                <UserPlus className="h-4 w-4 mr-2" />
                Seguir
              </button>
              <Link
                href="/profile/edit"
                className="p-2 rounded-full"
                style={{ border: "1px solid rgba(155, 126, 75, 0.3)" }}
              >
                <Settings className="h-5 w-5" style={{ color: "#e8e0d0" }} />
              </Link>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="w-full">
          {/* Tabs */}
          <div className="border-b mb-8" style={{ borderColor: "rgba(155, 126, 75, 0.2)" }}>
            <div className="flex -mb-px">
              <button className="px-4 py-2 font-medium border-b-2" style={{ borderColor: "#9b7e4b", color: "#e8e0d0" }}>
                Videos
              </button>
              <button className="px-4 py-2 font-medium" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                Favoritos
              </button>
              <button className="px-4 py-2 font-medium" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                Sobre mí
              </button>
            </div>
          </div>

          {/* Videos Tab Content */}
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Video Card 1 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="La 'Mano de Dios'- Maradona vs Inglaterra(1986)"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Jugadores legendarios</span>
                  </div>
                  <p className="font-bold text-lg text-start my-2" style={{ color: "#e8e0d0" }}>
                    La 'Mano de Dios'- Maradona vs Inglaterra(1986)
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 45k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 3.2k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 1.2M
                    </span>
                  </div>
                </div>
              </div>

              {/* Video Card 2 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="Gol de Iniesta - España vs Holanda (2010)"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Goles icónicos</span>
                  </div>
                  <p className="font-bold text-lg text-start my-2" style={{ color: "#e8e0d0" }}>
                    Gol de Iniesta - España vs Holanda (2010)
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 38k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 2.7k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 980k
                    </span>
                  </div>
                </div>
              </div>

              {/* Video Card 3 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="Brasil vs Italia - Final Mundial 1994"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Partidos memorables</span>
                  </div>
                  <p className="font-bold text-lg text-start my-2" style={{ color: "#e8e0d0" }}>
                    Brasil vs Italia - Final Mundial 1994
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 32k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 1.8k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 850k
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Load More Button */}
            <div className="text-center mt-8">
              <button className="btn-primary" style={{ width: "220px" }}>
                CARGAR MÁS VIDEOS
              </button>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
