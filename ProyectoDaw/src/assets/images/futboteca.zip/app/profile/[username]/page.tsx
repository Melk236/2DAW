"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Eye, Settings, UserPlus, Users, Grid, Bookmark, Trophy } from "lucide-react"
import VideoCard from "@/components/video-card"

// Datos de ejemplo
const profileData = {
  username: "FutbolHistórico",
  displayName: "Fútbol Histórico",
  avatar: "/placeholder.svg?height=128&width=128",
  cover: "/placeholder.svg?height=300&width=1024",
  bio: "Compartiendo los mejores momentos del fútbol mundial. Revive la historia del deporte rey a través de nuestros videos.",
  followers: "15.2k",
  following: "245",
  views: "2.5M",
  isVerified: true,
  joinDate: "Junio 2020",
}

const userVideos = [
  {
    id: 1,
    title: "La 'Mano de Dios'- Maradona vs Inglaterra (1986)",
    username: "FutbolHistórico",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "45k",
    comments: "3.2k",
    views: "1.2M",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
  {
    id: 2,
    title: "Gol de Iniesta - España vs Holanda (2010)",
    username: "FutbolHistórico",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "38k",
    comments: "2.7k",
    views: "980k",
    category: "goals",
    categoryName: "Goles icónicos",
  },
  {
    id: 3,
    title: "Brasil vs Italia - Final Mundial 1994",
    username: "FutbolHistórico",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "32k",
    comments: "1.8k",
    views: "850k",
    category: "matches",
    categoryName: "Partidos memorables",
  },
]

const favoriteVideos = [
  {
    id: 4,
    title: "Zidane vs Brasil - Mundial 2006",
    username: "LegendsFutbol",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "29k",
    comments: "1.5k",
    views: "720k",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
  {
    id: 5,
    title: "Gol de Messi vs México - Mundial 2022",
    username: "MundialHistoria",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "25k",
    comments: "1.2k",
    views: "650k",
    category: "goals",
    categoryName: "Goles icónicos",
  },
]

export default function Profile({ params }: { params: { username: string } }) {
  const [activeTab, setActiveTab] = useState("videos")
  const [isFollowing, setIsFollowing] = useState(false)

  // Determinar si es el perfil del usuario actual
  const isCurrentUser = params.username === "me" || params.username === "FutbolHistórico"

  return (
    <main className="pt-16">
      {/* Portada */}
      <div className="relative h-48 md:h-64 lg:h-80">
        <Image src={profileData.cover || "/placeholder.svg"} alt="Cover" fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#14100c] to-transparent"></div>
      </div>

      {/* Información del perfil */}
      <div className="container mx-auto px-4">
        <div className="relative -mt-16 md:-mt-20 z-10 flex flex-col md:flex-row md:items-end gap-6 mb-8">
          {/* Avatar */}
          <div className="flex flex-col items-center md:items-start">
            <div className="avatar w-32 h-32 border-4 border-[#14100c] shadow-gold">
              <Image
                src={profileData.avatar || "/placeholder.svg"}
                alt={profileData.username}
                width={128}
                height={128}
                className="rounded-full object-cover"
              />
              {profileData.isVerified && (
                <div className="absolute bottom-0 right-0 bg-[#d4af37] text-[#14100c] rounded-full p-1">
                  <Trophy className="h-5 w-5" />
                </div>
              )}
            </div>
          </div>

          {/* Información del usuario */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col md:flex-row md:items-center gap-2">
              <h1 className="text-2xl font-bold">{profileData.displayName}</h1>
              <span className="text-[#e8e0d0]/70">@{profileData.username}</span>
            </div>
            <p className="text-[#e8e0d0]/80 mt-2 max-w-2xl">{profileData.bio}</p>

            <div className="flex flex-wrap justify-center md:justify-start gap-6 mt-4">
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-[#9b7e4b]" />
                <span className="font-medium">{profileData.followers}</span>
                <span className="text-[#e8e0d0]/70 text-sm">seguidores</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-[#9b7e4b]" />
                <span className="font-medium">{profileData.following}</span>
                <span className="text-[#e8e0d0]/70 text-sm">siguiendo</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4 text-[#9b7e4b]" />
                <span className="font-medium">{profileData.views}</span>
                <span className="text-[#e8e0d0]/70 text-sm">vistas</span>
              </div>
              <div className="flex items-center gap-1 text-[#e8e0d0]/70">
                <span className="text-sm">Miembro desde {profileData.joinDate}</span>
              </div>
            </div>
          </div>

          {/* Botones de acción */}
          <div className="flex justify-center md:justify-end gap-2 mt-4 md:mt-0">
            {isCurrentUser ? (
              <Link href="/profile/edit" className="btn-secondary">
                <Settings className="h-4 w-4 mr-2" />
                Editar perfil
              </Link>
            ) : (
              <button
                className={isFollowing ? "btn-secondary" : "btn-primary"}
                onClick={() => setIsFollowing(!isFollowing)}
              >
                {isFollowing ? (
                  <>
                    <Users className="h-4 w-4 mr-2" />
                    Siguiendo
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Seguir
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Pestañas */}
        <div className="border-b border-[#9b7e4b]/20 mb-6">
          <div className="flex">
            <button className={`tab ${activeTab === "videos" ? "active" : ""}`} onClick={() => setActiveTab("videos")}>
              <Grid className="h-4 w-4 mr-2" />
              Videos
            </button>
            <button
              className={`tab ${activeTab === "favorites" ? "active" : ""}`}
              onClick={() => setActiveTab("favorites")}
            >
              <Bookmark className="h-4 w-4 mr-2" />
              Favoritos
            </button>
            <button className={`tab ${activeTab === "about" ? "active" : ""}`} onClick={() => setActiveTab("about")}>
              <Users className="h-4 w-4 mr-2" />
              Sobre mí
            </button>
          </div>
        </div>

        {/* Contenido de las pestañas */}
        {activeTab === "videos" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
            {userVideos.map((video) => (
              <VideoCard key={video.id} {...video} />
            ))}
          </div>
        )}

        {activeTab === "favorites" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
            {favoriteVideos.map((video) => (
              <VideoCard key={video.id} {...video} />
            ))}
          </div>
        )}

        {activeTab === "about" && (
          <div className="card p-6 max-w-3xl mx-auto animate-fade-in">
            <h2 className="text-xl font-bold mb-4">Sobre {profileData.displayName}</h2>
            <p className="mb-4">
              Somos apasionados del fútbol y su rica historia. Nuestro objetivo es preservar y compartir los momentos
              más emblemáticos que han definido este hermoso deporte a lo largo de las décadas.
            </p>
            <p className="mb-4">
              Desde goles icónicos hasta partidos memorables, queremos que las nuevas generaciones conozcan y aprecien
              la evolución del fútbol y a sus grandes protagonistas.
            </p>

            <h3 className="text-lg font-bold mt-6 mb-3">Información de contacto</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <span className="text-[#9b7e4b]">Email:</span> contacto@futbolhistorico.com
              </li>
              <li className="flex items-center gap-2">
                <span className="text-[#9b7e4b]">Twitter:</span> @FutbolHistorico
              </li>
              <li className="flex items-center gap-2">
                <span className="text-[#9b7e4b]">Instagram:</span> @futbol_historico
              </li>
            </ul>
          </div>
        )}
      </div>
    </main>
  )
}
