"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"

export default function Register() {
  const router = useRouter()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Validate passwords match
    if (password !== confirmPassword) {
      setError("Las contraseñas no coinciden")
      return
    }

    setIsLoading(true)

    // Simulate registration
    setTimeout(() => {
      setIsLoading(false)
      router.push("/feed")
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left Side - Image */}
      <div className="hidden md:block md:flex-1" style={{ backgroundColor: "rgba(155, 126, 75, 0.1)" }}>
        <div className="h-full flex items-center justify-center p-8">
          <div className="max-w-lg text-center">
            <h2 className="text-3xl font-bold mb-4" style={{ color: "#e8e0d0" }}>
              Únete a Futboteca
            </h2>
            <p className="text-lg mb-8" style={{ color: "#e8e0d0" }}>
              Comparte, descubre y comenta los momentos más emblemáticos de la historia del fútbol mundial.
            </p>
            <Image
              src="/placeholder.svg?height=300&width=500"
              alt="Futboteca Preview"
              width={500}
              height={300}
              className="rounded-lg mx-auto card-hover"
            />
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold" style={{ color: "#e8e0d0" }}>
              FUTBOTECA
            </h1>
            <p style={{ color: "rgba(232, 224, 208, 0.7)", marginTop: "0.5rem" }}>Crea tu cuenta</p>
          </div>

          {error && (
            <div
              className="rounded-lg p-4 mb-6"
              style={{ backgroundColor: "rgba(220, 38, 38, 0.1)", border: "1px solid rgba(220, 38, 38, 0.5)" }}
            >
              <p style={{ color: "#ef4444" }}>{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="name" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Nombre de usuario
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Tu nombre de usuario"
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="email" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@email.com"
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="password" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Contraseña
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="confirmPassword" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Confirmar contraseña
              </label>
              <input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
            </div>

            <div className="flex items-start">
              <input id="terms" type="checkbox" className="mt-1 mr-2" required />
              <label htmlFor="terms" className="text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                Acepto los{" "}
                <Link href="/terms" style={{ color: "#9b7e4b" }}>
                  Términos de Servicio
                </Link>{" "}
                y la{" "}
                <Link href="/privacy" style={{ color: "#9b7e4b" }}>
                  Política de Privacidad
                </Link>
              </label>
            </div>

            <button type="submit" disabled={isLoading} className="btn-primary w-full">
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div
                    className="h-5 w-5 rounded-full animate-spin"
                    style={{ border: "2px solid rgba(232, 224, 208, 0.2)", borderTopColor: "#e8e0d0" }}
                  ></div>
                  <span>Creando cuenta...</span>
                </div>
              ) : (
                "Crear Cuenta"
              )}
            </button>
          </form>

          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full" style={{ borderTop: "1px solid rgba(232, 224, 208, 0.2)" }}></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2" style={{ backgroundColor: "#14100c", color: "rgba(232, 224, 208, 0.6)" }}>
                  O regístrate con
                </span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3">
              <button
                className="flex justify-center items-center py-2 px-4 rounded-lg"
                style={{ border: "1px solid rgba(155, 126, 75, 0.3)", color: "#e8e0d0" }}
              >
                Google
              </button>
              <button
                className="flex justify-center items-center py-2 px-4 rounded-lg"
                style={{ border: "1px solid rgba(155, 126, 75, 0.3)", color: "#e8e0d0" }}
              >
                Facebook
              </button>
              <button
                className="flex justify-center items-center py-2 px-4 rounded-lg"
                style={{ border: "1px solid rgba(155, 126, 75, 0.3)", color: "#e8e0d0" }}
              >
                Twitter
              </button>
            </div>
          </div>

          <p className="mt-8 text-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
            ¿Ya tienes una cuenta?{" "}
            <Link href="/login" style={{ color: "#9b7e4b" }}>
              Inicia sesión
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
