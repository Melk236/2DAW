import Image from "next/image"
import Link from "next/link"
import { Heart, MessageSquare, Eye, Filter } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Feed() {
  return (
    <>
      <Navbar />
      <main style={{ paddingTop: "6rem", paddingBottom: "4rem" }} className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Left Sidebar - Categories */}
          <aside className="md:w-64 lg:w-72 hidden md:block">
            <div
              className="sticky top-24 p-4 rounded-lg"
              style={{
                backgroundColor: "rgba(20, 16, 12, 0.5)",
                backdropFilter: "blur(8px)",
                border: "1px solid rgba(155, 126, 75, 0.2)",
              }}
            >
              <h3 className="font-bold text-lg mb-4" style={{ color: "#e8e0d0" }}>
                Categorías
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/feed?category=all"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Todos los videos
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?category=goals"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Goles icónicos
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?category=matches"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Partidos memorables
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?category=players"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Jugadores legendarios
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?category=tournaments"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Torneos históricos
                  </Link>
                </li>
              </ul>

              <h3 className="font-bold text-lg mt-8 mb-4" style={{ color: "#e8e0d0" }}>
                Filtrar por
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/feed?sort=recent"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Más recientes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?sort=popular"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Más populares
                  </Link>
                </li>
                <li>
                  <Link
                    href="/feed?sort=trending"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Tendencias
                  </Link>
                </li>
              </ul>
            </div>
          </aside>

          {/* Mobile Filter Button */}
          <div className="md:hidden mb-4">
            <button
              className="w-full flex items-center justify-center gap-2 p-3 rounded-lg"
              style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0" }}
            >
              <Filter size={18} />
              <span>Filtrar videos</span>
            </button>
          </div>

          {/* Main Content - Video Feed */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold" style={{ color: "#e8e0d0" }}>
                Feed de Videos
              </h1>
              <div className="flex gap-2">
                <button
                  className="px-3 py-1 rounded-full"
                  style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0", fontSize: "0.875rem" }}
                >
                  Recientes
                </button>
                <button
                  className="px-3 py-1 rounded-full"
                  style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0", fontSize: "0.875rem" }}
                >
                  Populares
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Video Card 1 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="La 'Mano de Dios'- Maradona vs Inglaterra(1986)"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Jugadores legendarios</span>
                  </div>
                  <p className="font-bold text-xl text-start my-2" style={{ color: "#e8e0d0" }}>
                    La 'Mano de Dios'- Maradona vs Inglaterra(1986)
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 45k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 3.2k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 1.2M
                    </span>
                    <span className="ml-auto">10/06/2023</span>
                  </div>
                  <hr style={{ margin: "0.5rem 0", borderColor: "rgba(232, 224, 208, 0.1)" }} />
                  <div className="flex gap-3 items-center">
                    <Image
                      src="/placeholder.svg?height=30&width=30"
                      alt="User Avatar"
                      width={30}
                      height={30}
                      className="rounded-full"
                    />
                    <span style={{ color: "#e8e0d0" }}>Futboteca</span>
                  </div>
                </div>
              </div>

              {/* Video Card 2 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="Gol de Iniesta - España vs Holanda (2010)"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Goles icónicos</span>
                  </div>
                  <p className="font-bold text-xl text-start my-2" style={{ color: "#e8e0d0" }}>
                    Gol de Iniesta - España vs Holanda (2010)
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 38k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 2.7k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 980k
                    </span>
                    <span className="ml-auto">15/05/2023</span>
                  </div>
                  <hr style={{ margin: "0.5rem 0", borderColor: "rgba(232, 224, 208, 0.1)" }} />
                  <div className="flex gap-3 items-center">
                    <Image
                      src="/placeholder.svg?height=30&width=30"
                      alt="User Avatar"
                      width={30}
                      height={30}
                      className="rounded-full"
                    />
                    <span style={{ color: "#e8e0d0" }}>FutbolHistórico</span>
                  </div>
                </div>
              </div>

              {/* Video Card 3 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="Brasil vs Italia - Final Mundial 1994"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Partidos memorables</span>
                  </div>
                  <p className="font-bold text-xl text-start my-2" style={{ color: "#e8e0d0" }}>
                    Brasil vs Italia - Final Mundial 1994
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 32k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 1.8k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 850k
                    </span>
                    <span className="ml-auto">22/04/2023</span>
                  </div>
                  <hr style={{ margin: "0.5rem 0", borderColor: "rgba(232, 224, 208, 0.1)" }} />
                  <div className="flex gap-3 items-center">
                    <Image
                      src="/placeholder.svg?height=30&width=30"
                      alt="User Avatar"
                      width={30}
                      height={30}
                      className="rounded-full"
                    />
                    <span style={{ color: "#e8e0d0" }}>MundialHistoria</span>
                  </div>
                </div>
              </div>

              {/* Video Card 4 */}
              <div className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?modestbranding=1&rel=0"
                    title="Zidane vs Brasil - Mundial 2006"
                    className="absolute top-0 left-0 w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">Jugadores legendarios</span>
                  </div>
                  <p className="font-bold text-xl text-start my-2" style={{ color: "#e8e0d0" }}>
                    Zidane vs Brasil - Mundial 2006
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> 29k
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> 1.5k
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> 720k
                    </span>
                    <span className="ml-auto">05/03/2023</span>
                  </div>
                  <hr style={{ margin: "0.5rem 0", borderColor: "rgba(232, 224, 208, 0.1)" }} />
                  <div className="flex gap-3 items-center">
                    <Image
                      src="/placeholder.svg?height=30&width=30"
                      alt="User Avatar"
                      width={30}
                      height={30}
                      className="rounded-full"
                    />
                    <span style={{ color: "#e8e0d0" }}>LegendsFutbol</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Load More Button */}
            <div className="text-center mt-10">
              <button className="btn-primary" style={{ width: "220px" }}>
                CARGAR MÁS VIDEOS
              </button>
            </div>
          </div>

          {/* Right Sidebar - Recommended */}
          <aside className="md:w-64 lg:w-72 hidden lg:block">
            <div
              className="sticky top-24 p-4 rounded-lg"
              style={{
                backgroundColor: "rgba(20, 16, 12, 0.5)",
                backdropFilter: "blur(8px)",
                border: "1px solid rgba(155, 126, 75, 0.2)",
              }}
            >
              <h3 className="font-bold text-lg mb-4" style={{ color: "#e8e0d0" }}>
                Recomendados
              </h3>

              <div className="space-y-4">
                {/* Recommended Video 1 */}
                <div className="group">
                  <Link href="/video/1" className="flex gap-2">
                    <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=80&width=80"
                        alt="Video thumbnail"
                        width={80}
                        height={80}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <p className="font-medium text-sm line-clamp-2" style={{ color: "#e8e0d0" }}>
                        Gol de Messi vs México - Mundial 2022
                      </p>
                      <p className="text-xs mt-1" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                        250k vistas
                      </p>
                    </div>
                  </Link>
                </div>

                {/* Recommended Video 2 */}
                <div className="group">
                  <Link href="/video/2" className="flex gap-2">
                    <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=80&width=80"
                        alt="Video thumbnail"
                        width={80}
                        height={80}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <p className="font-medium text-sm line-clamp-2" style={{ color: "#e8e0d0" }}>
                        Final Champions 2005 - Liverpool vs Milan
                      </p>
                      <p className="text-xs mt-1" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                        420k vistas
                      </p>
                    </div>
                  </Link>
                </div>

                {/* Recommended Video 3 */}
                <div className="group">
                  <Link href="/video/3" className="flex gap-2">
                    <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=80&width=80"
                        alt="Video thumbnail"
                        width={80}
                        height={80}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <p className="font-medium text-sm line-clamp-2" style={{ color: "#e8e0d0" }}>
                        Ronaldinho vs Real Madrid (2005)
                      </p>
                      <p className="text-xs mt-1" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                        680k vistas
                      </p>
                    </div>
                  </Link>
                </div>

                {/* Recommended Video 4 */}
                <div className="group">
                  <Link href="/video/4" className="flex gap-2">
                    <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden">
                      <Image
                        src="/placeholder.svg?height=80&width=80"
                        alt="Video thumbnail"
                        width={80}
                        height={80}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <div>
                      <p className="font-medium text-sm line-clamp-2" style={{ color: "#e8e0d0" }}>
                        Gol de Zidane - Final Champions 2002
                      </p>
                      <p className="text-xs mt-1" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                        520k vistas
                      </p>
                    </div>
                  </Link>
                </div>
              </div>

              <h3 className="font-bold text-lg mt-8 mb-4" style={{ color: "#e8e0d0" }}>
                Usuarios populares
              </h3>
              <div className="space-y-3">
                {/* User 1 */}
                <Link href="/profile/1" className="flex items-center gap-3 p-2 rounded hover:bg-primary-hover">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="User Avatar"
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div>
                    <p className="font-medium text-sm" style={{ color: "#e8e0d0" }}>
                      FutbolHistórico
                    </p>
                    <p className="text-xs" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                      15.2k seguidores
                    </p>
                  </div>
                </Link>

                {/* User 2 */}
                <Link href="/profile/2" className="flex items-center gap-3 p-2 rounded hover:bg-primary-hover">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="User Avatar"
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div>
                    <p className="font-medium text-sm" style={{ color: "#e8e0d0" }}>
                      MundialHistoria
                    </p>
                    <p className="text-xs" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                      12.8k seguidores
                    </p>
                  </div>
                </Link>

                {/* User 3 */}
                <Link href="/profile/3" className="flex items-center gap-3 p-2 rounded hover:bg-primary-hover">
                  <Image
                    src="/placeholder.svg?height=40&width=40"
                    alt="User Avatar"
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div>
                    <p className="font-medium text-sm" style={{ color: "#e8e0d0" }}>
                      LegendsFutbol
                    </p>
                    <p className="text-xs" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                      9.5k seguidores
                    </p>
                  </div>
                </Link>
              </div>
            </div>
          </aside>
        </div>
      </main>
      <Footer />
    </>
  )
}
