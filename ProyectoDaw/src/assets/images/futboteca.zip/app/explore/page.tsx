"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Search, Filter } from "lucide-react"
import CategoryFilter from "@/components/category-filter"
import VideoCard from "@/components/video-card"

// Datos de ejemplo - videos de otros usuarios (descubrimiento)
const discoverVideos = [
  {
    id: 1,
    title: "La 'Mano de Dios'- Maradona vs Inglaterra (1986)",
    username: "FutbolClásico",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "45k",
    comments: "3.2k",
    views: "1.2M",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
  {
    id: 2,
    title: "Gol de Iniesta - España vs Holanda (2010)",
    username: "MundialHistoria",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "38k",
    comments: "2.7k",
    views: "980k",
    category: "goals",
    categoryName: "Goles icónicos",
  },
  {
    id: 3,
    title: "Brasil vs Italia - Final Mundial 1994",
    username: "CopasDelMundo",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "32k",
    comments: "1.8k",
    views: "850k",
    category: "matches",
    categoryName: "Partidos memorables",
  },
  {
    id: 4,
    title: "Zidane vs Brasil - Mundial 2006",
    username: "LegendsFutbol",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "29k",
    comments: "1.5k",
    views: "720k",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
  {
    id: 5,
    title: "Final Champions 2005 - Liverpool vs Milan",
    username: "ChampionsHistory",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "41k",
    comments: "2.9k",
    views: "1.1M",
    category: "matches",
    categoryName: "Partidos memorables",
  },
  {
    id: 6,
    title: "Ronaldinho vs Real Madrid (2005)",
    username: "BarçaLegends",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "36k",
    comments: "2.2k",
    views: "950k",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
]

const categories = [
  { id: "trending", name: "Tendencias" },
  { id: "goals", name: "Goles icónicos" },
  { id: "matches", name: "Partidos memorables" },
  { id: "players", name: "Jugadores legendarios" },
  { id: "tournaments", name: "Torneos históricos" },
  { id: "teams", name: "Equipos" },
]

const popularCreators = [
  {
    username: "FutbolClásico",
    avatar: "/placeholder.svg?height=64&width=64",
    followers: "125K",
  },
  {
    username: "MundialHistoria",
    avatar: "/placeholder.svg?height=64&width=64",
    followers: "98K",
  },
  {
    username: "LegendsFutbol",
    avatar: "/placeholder.svg?height=64&width=64",
    followers: "87K",
  },
  {
    username: "ChampionsHistory",
    avatar: "/placeholder.svg?height=64&width=64",
    followers: "76K",
  },
]

export default function Explore() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("trending")
  const [videos, setVideos] = useState(discoverVideos)
  const [showMobileFilter, setShowMobileFilter] = useState(false)

  useEffect(() => {
    // Filtrar videos según la categoría seleccionada
    if (activeCategory === "trending") {
      setVideos(discoverVideos)
    } else {
      setVideos(discoverVideos.filter((video) => video.category === activeCategory))
    }
  }, [activeCategory])

  return (
    <main className="pt-20 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6 text-gradient">Explorar</h1>

        {/* Buscador */}
        <div className="relative mb-6">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Descubre nuevos videos y creadores..."
            className="w-full pl-12 pr-4 py-3 rounded-full bg-[#14100c] text-[#e8e0d0] border border-[#9b7e4b]/30 focus:outline-none focus:border-[#9b7e4b]"
          />
          <Search className="absolute left-4 top-3.5 h-5 w-5 text-[#e8e0d0]/60" />
        </div>

        {/* Filtro de categorías */}
        <div className="mb-6">
          <CategoryFilter categories={categories} activeCategory={activeCategory} onChange={setActiveCategory} />
        </div>

        {/* Botón de filtro móvil */}
        <div className="md:hidden mb-4">
          <button
            className="w-full flex items-center justify-center gap-2 p-3 rounded-lg"
            style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0" }}
            onClick={() => setShowMobileFilter(!showMobileFilter)}
          >
            <Filter size={18} />
            <span>Filtrar videos</span>
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar - Solo visible en desktop */}
          <aside className="md:w-64 lg:w-72 hidden md:block">
            <div
              className="sticky top-24 p-4 rounded-lg"
              style={{
                backgroundColor: "rgba(20, 16, 12, 0.5)",
                backdropFilter: "blur(8px)",
                border: "1px solid rgba(155, 126, 75, 0.2)",
              }}
            >
              <h3 className="font-bold text-lg mb-4" style={{ color: "#e8e0d0" }}>
                Creadores Populares
              </h3>
              <div className="space-y-3">
                {popularCreators.map((creator, index) => (
                  <Link
                    key={index}
                    href={`/profile/${creator.username}`}
                    className="flex items-center gap-3 p-2 rounded hover:bg-primary-hover"
                  >
                    <Image
                      src={creator.avatar || "/placeholder.svg"}
                      alt={creator.username}
                      width={40}
                      height={40}
                      className="rounded-full"
                    />
                    <div>
                      <p className="font-medium text-sm" style={{ color: "#e8e0d0" }}>
                        {creator.username}
                      </p>
                      <p className="text-xs" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                        {creator.followers} seguidores
                      </p>
                    </div>
                  </Link>
                ))}
              </div>

              <h3 className="font-bold text-lg mt-8 mb-4" style={{ color: "#e8e0d0" }}>
                Filtrar por
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/explore?sort=recent"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Más recientes
                  </Link>
                </li>
                <li>
                  <Link
                    href="/explore?sort=popular"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Más populares
                  </Link>
                </li>
                <li>
                  <Link
                    href="/explore?sort=trending"
                    className="block p-2 rounded hover:bg-primary-hover"
                    style={{ color: "#e8e0d0" }}
                  >
                    Tendencias
                  </Link>
                </li>
              </ul>
            </div>
          </aside>

          {/* Contenido principal */}
          <div className="flex-1">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold" style={{ color: "#e8e0d0" }}>
                {activeCategory === "trending"
                  ? "Tendencias"
                  : activeCategory === "goals"
                    ? "Goles icónicos"
                    : activeCategory === "matches"
                      ? "Partidos memorables"
                      : activeCategory === "players"
                        ? "Jugadores legendarios"
                        : activeCategory === "tournaments"
                          ? "Torneos históricos"
                          : activeCategory === "teams"
                            ? "Equipos"
                            : "Videos"}
              </h2>
              <div className="flex gap-2">
                <button
                  className="px-3 py-1 rounded-full"
                  style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0", fontSize: "0.875rem" }}
                >
                  Recientes
                </button>
                <button
                  className="px-3 py-1 rounded-full"
                  style={{ border: "1px solid rgba(155, 126, 75, 0.2)", color: "#e8e0d0", fontSize: "0.875rem" }}
                >
                  Populares
                </button>
              </div>
            </div>

            {/* Grid de videos */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videos.map((video) => (
                <VideoCard key={video.id} {...video} />
              ))}
            </div>

            {videos.length === 0 && (
              <div className="text-center py-12">
                <p className="text-xl" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                  No se encontraron videos para esta categoría
                </p>
                <button onClick={() => setActiveCategory("trending")} className="btn-primary mt-4">
                  Ver tendencias
                </button>
              </div>
            )}

            {/* Botón de cargar más */}
            <div className="text-center mt-10">
              <button className="btn-primary" style={{ width: "220px" }}>
                CARGAR MÁS VIDEOS
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
