"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import EraSelector from "@/components/era-selector"

const eras = [
  { id: "1950s", year: "1950s", title: "Era Pelé" },
  { id: "1960s", year: "1960s", title: "Fútbol Total" },
  { id: "1970s", year: "1970s", title: "Brasil Dorado" },
  { id: "1980s", year: "1980s", title: "Era Maradona" },
  { id: "1990s", year: "1990s", title: "Ronaldo" },
  { id: "2000s", year: "2000s", title: "Zidane" },
  { id: "2010s", year: "2010s", title: "Messi vs CR7" },
  { id: "2020s", year: "2020s", title: "Nueva Era" },
]

const eraContent = {
  "1980s": {
    title: "Los 80s: La Era de Maradona",
    description:
      "La década de 1980 estuvo marcada por el surgimiento de Diego Armando Maradona como la figura más dominante del fútbol mundial. Su actuación en el Mundial de México 1986 es considerada una de las mejores de la historia.",
    image: "/placeholder.svg?height=400&width=600",
    keyPlayers: [
      { name: "Diego Maradona", country: "Argentina", image: "/placeholder.svg?height=100&width=100" },
      { name: "Michel Platini", country: "Francia", image: "/placeholder.svg?height=100&width=100" },
      { name: "Karl-Heinz Rummenigge", country: "Alemania", image: "/placeholder.svg?height=100&width=100" },
      { name: "Marco van Basten", country: "Holanda", image: "/placeholder.svg?height=100&width=100" },
    ],
    keyMoments: [
      {
        title: "La Mano de Dios",
        description: "Maradona anota con la mano contra Inglaterra en cuartos de final del Mundial 1986",
        year: 1986,
        videoId: 1,
      },
      {
        title: "El Gol del Siglo",
        description: "Maradona recorre medio campo y anota el mejor gol de la historia de los Mundiales",
        year: 1986,
        videoId: 2,
      },
      {
        title: "Eurocopa 1988",
        description: "Holanda gana su primer título europeo con un golazo de volea de Van Basten",
        year: 1988,
        videoId: 3,
      },
    ],
    tournaments: [
      { name: "Mundial España", year: 1982, winner: "Italia" },
      { name: "Eurocopa", year: 1984, winner: "Francia" },
      { name: "Mundial México", year: 1986, winner: "Argentina" },
      { name: "Eurocopa", year: 1988, winner: "Holanda" },
    ],
  },
}

export default function ErasPage() {
  const [activeEra, setActiveEra] = useState("1980s")
  const content = eraContent[activeEra as keyof typeof eraContent] || eraContent["1980s"]

  return (
    <main className="pt-20 pb-16 container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-6 text-gradient">Épocas del Fútbol</h1>

      <EraSelector eras={eras} activeEra={activeEra} onChange={setActiveEra} />

      <div className="mt-8 animate-fade-in">
        <div className="interactive-banner mb-8 h-[300px] md:h-[400px]">
          <Image
            src={content.image || "/placeholder.svg"}
            alt={content.title}
            fill
            className="object-cover rounded-lg"
          />
          <div className="content">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">{content.title}</h2>
            <p className="mb-4 text-[#e8e0d0]/80">{content.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Columna izquierda - Jugadores clave */}
          <div className="card p-6">
            <h3 className="text-xl font-bold mb-4">Jugadores Destacados</h3>
            <div className="space-y-4">
              {content.keyPlayers.map((player, index) => (
                <Link
                  href={`/players/${player.name.toLowerCase().replace(/\s+/g, "-")}`}
                  key={index}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-[#9b7e4b]/10 transition-colors"
                >
                  <Image
                    src={player.image || "/placeholder.svg"}
                    alt={player.name}
                    width={50}
                    height={50}
                    className="rounded-full border-2 border-[#9b7e4b]"
                  />
                  <div>
                    <h4 className="font-bold">{player.name}</h4>
                    <p className="text-sm text-[#e8e0d0]/70">{player.country}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Columna central - Momentos clave */}
          <div className="card p-6">
            <h3 className="text-xl font-bold mb-4">Momentos Históricos</h3>
            <div className="timeline">
              {content.keyMoments.map((moment, index) => (
                <Link
                  href={`/video/${moment.videoId}`}
                  key={index}
                  className="timeline-item block hover:text-[#9b7e4b] transition-colors"
                >
                  <span className="timeline-date">{moment.year}</span>
                  <h4 className="font-bold">{moment.title}</h4>
                  <p className="text-sm text-[#e8e0d0]/70">{moment.description}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Columna derecha - Torneos */}
          <div className="card p-6">
            <h3 className="text-xl font-bold mb-4">Torneos Importantes</h3>
            <div className="space-y-4">
              {content.tournaments.map((tournament, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center p-2 border-b border-[#9b7e4b]/20 last:border-0"
                >
                  <div>
                    <h4 className="font-medium">{tournament.name}</h4>
                    <p className="text-sm text-[#e8e0d0]/70">{tournament.year}</p>
                  </div>
                  <div className="trophy-icon">
                    <span className="text-[#14100c] font-bold text-xs">{tournament.winner}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-center">
              <Link href={`/tournaments?era=${activeEra}`} className="btn-primary">
                Ver todos los torneos
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
