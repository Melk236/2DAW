"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, MessageSquare, Eye, Share2, BookmarkPlus, Send } from "lucide-react"

// Datos de ejemplo
const videoData = {
  id: 1,
  title: "La 'Mano de Dios'- Maradona vs Inglaterra (1986)",
  description:
    "El 22 de junio de 1986, en el Estadio Azteca de México, Diego Armando Maradona protagonizó uno de los momentos más controvertidos y a la vez brillantes de la historia del fútbol. En el partido de cuartos de final del Mundial entre Argentina e Inglaterra, Maradona anotó dos goles que pasarían a la historia: la famosa 'Mano de Dios' y el considerado 'Gol del Siglo'.\n\nEste video muestra el primer gol, donde Maradona saltó junto al portero inglés Peter Shilton y con la mano izquierda desvió el balón a la red. El árbitro no vio la infracción y concedió el gol, que pasaría a la historia como la 'Mano de Dios', nombre que el propio Maradona le dio en la rueda de prensa posterior al partido.",
  username: "Futboteca",
  userAvatar: "/placeholder.svg?height=48&width=48",
  videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
  likes: "45k",
  comments: "3.2k",
  views: "1.2M",
  category: "players",
  categoryName: "Jugadores legendarios",
  date: "10/06/2023",
  isVerified: true,
  followers: "15.2k",
}

const relatedVideos = [
  {
    id: 2,
    title: "El gol del siglo - Maradona vs Inglaterra (1986)",
    username: "Futboteca",
    userAvatar: "/placeholder.svg?height=48&width=48",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    views: "1.5M",
    date: "hace 1 año",
  },
  {
    id: 3,
    title: "Maradona - Mejores jugadas y goles",
    username: "LegendsFutbol",
    userAvatar: "/placeholder.svg?height=48&width=48",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    views: "980k",
    date: "hace 2 años",
  },
  {
    id: 4,
    title: "Argentina vs Inglaterra - Mundial 1986 (Partido Completo)",
    username: "MundialHistoria",
    userAvatar: "/placeholder.svg?height=48&width=48",
    thumbnail: "/placeholder.svg?height=180&width=320",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    views: "720k",
    date: "hace 3 años",
  },
]

const initialComments = [
  {
    id: 1,
    user: {
      name: "Carlos Martínez",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    text: "¡Qué golazo! Uno de los mejores momentos de la historia del fútbol sin duda.",
    date: "hace 2 días",
    likes: 24,
    isLiked: false,
  },
  {
    id: 2,
    user: {
      name: "Laura Sánchez",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    text: "Recuerdo ver este partido en vivo, fue increíble la emoción que se vivió.",
    date: "hace 5 días",
    likes: 18,
    isLiked: false,
  },
]

export default function VideoDetail({ params }: { params: { id: string } }) {
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [isFollowing, setIsFollowing] = useState(false)
  const [comment, setComment] = useState("")
  const [comments, setComments] = useState(initialComments)
  const [showFullDescription, setShowFullDescription] = useState(false)

  // Simular incremento de likes
  const [likesCount, setLikesCount] = useState(videoData.likes)

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikesCount(isLiked ? "45k" : "45.1k") // Simulación simple
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
  }

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  const handleCommentLike = (commentId: number) => {
    setComments(
      comments.map((c) =>
        c.id === commentId
          ? {
              ...c,
              isLiked: !c.isLiked,
              likes: c.isLiked ? c.likes - 1 : c.likes + 1,
            }
          : c,
      ),
    )
  }

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!comment.trim()) return

    const newComment = {
      id: comments.length + 1,
      user: {
        name: "Usuario Actual",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      text: comment,
      date: "ahora mismo",
      likes: 0,
      isLiked: false,
    }

    setComments([newComment, ...comments])
    setComment("")
  }

  return (
    <main className="pt-16 pb-16 container mx-auto px-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Columna principal */}
        <div className="lg:col-span-2">
          {/* Reproductor de video */}
          <div className="relative pb-[56.25%] w-full rounded-lg overflow-hidden mb-4 shadow-gold">
            <iframe
              src={`${videoData.videoUrl}?autoplay=1`}
              title={videoData.title}
              className="absolute top-0 left-0 w-full h-full"
              allowFullScreen
              allow="autoplay"
            ></iframe>
          </div>

          {/* Información del video */}
          <div className="mb-6 animate-fade-in">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
              <div>
                <Link href={`/categories/${videoData.category}`} className="tag mb-2 hover-scale inline-block">
                  {videoData.categoryName}
                </Link>
                <h1 className="text-2xl font-bold">{videoData.title}</h1>
              </div>
              <div className="flex gap-2">
                <button
                  className={`btn-icon ${isLiked ? "active animate-pulse" : ""}`}
                  onClick={handleLike}
                  aria-label="Me gusta"
                >
                  <Heart className="h-6 w-6" fill={isLiked ? "currentColor" : "none"} />
                </button>
                <button className="btn-icon" aria-label="Compartir">
                  <Share2 className="h-6 w-6" />
                </button>
                <button
                  className={`btn-icon ${isSaved ? "active" : ""}`}
                  onClick={handleSave}
                  aria-label="Guardar en favoritos"
                >
                  <BookmarkPlus className="h-6 w-6" fill={isSaved ? "currentColor" : "none"} />
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-4 mt-4 text-sm text-[#e8e0d0]/70">
              <span className="flex items-center gap-1">
                <Heart size={16} className={isLiked ? "text-[#9b7e4b]" : ""} /> {likesCount}
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare size={16} /> {videoData.comments}
              </span>
              <span className="flex items-center gap-1">
                <Eye size={16} /> {videoData.views}
              </span>
              <span>{videoData.date}</span>
            </div>

            <hr className="my-4 border-[#9b7e4b]/20" />

            {/* Información del creador */}
            <div className="flex items-center gap-3">
              <Link href={`/profile/${videoData.username}`} className="relative">
                <Image
                  src={videoData.userAvatar || "/placeholder.svg"}
                  alt={videoData.username}
                  width={48}
                  height={48}
                  className="rounded-full avatar"
                />
                {videoData.isVerified && (
                  <div className="absolute bottom-0 right-0 bg-[#d4af37] text-[#14100c] rounded-full p-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                      <path
                        fillRule="evenodd"
                        d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                )}
              </Link>
              <div>
                <Link
                  href={`/profile/${videoData.username}`}
                  className="font-medium hover:text-[#9b7e4b] transition-colors"
                >
                  {videoData.username}
                </Link>
                <p className="text-sm text-[#e8e0d0]/70">{videoData.followers} seguidores</p>
              </div>
              <button className={isFollowing ? "btn-secondary ml-auto" : "btn-primary ml-auto"} onClick={handleFollow}>
                {isFollowing ? "Siguiendo" : "Seguir"}
              </button>
            </div>
          </div>

          {/* Descripción del video */}
          <div className="card p-4 mb-8 animate-fade-in">
            <h2 className="font-bold mb-2">Descripción</h2>
            <p className="text-[#e8e0d0]/80 whitespace-pre-line">
              {showFullDescription
                ? videoData.description
                : `${videoData.description.substring(0, 200)}${videoData.description.length > 200 ? "..." : ""}`}
            </p>
            {videoData.description.length > 200 && (
              <button
                className="text-[#9b7e4b] mt-2 font-medium hover:underline"
                onClick={() => setShowFullDescription(!showFullDescription)}
              >
                {showFullDescription ? "Mostrar menos" : "Leer más"}
              </button>
            )}
          </div>

          {/* Sección de comentarios */}
          <div className="animate-fade-in">
            <h2 className="font-bold text-xl mb-4">Comentarios ({comments.length})</h2>

            {/* Formulario de comentarios */}
            <form onSubmit={handleSubmitComment} className="flex gap-3 mb-6">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="User Avatar"
                width={40}
                height={40}
                className="rounded-full flex-shrink-0"
              />
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Añade un comentario..."
                  className="w-full p-3 pr-12 rounded-lg bg-[#14100c] text-[#e8e0d0] border border-[#9b7e4b]/30 focus:outline-none focus:border-[#9b7e4b]"
                />
                <button
                  type="submit"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#9b7e4b] hover:text-[#d4af37] transition-colors"
                  disabled={!comment.trim()}
                >
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </form>

            {/* Lista de comentarios */}
            <div className="space-y-6">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3 animate-slide-up">
                  <Link href={`/profile/${comment.user.name}`}>
                    <Image
                      src={comment.user.avatar || "/placeholder.svg"}
                      alt={`${comment.user.name} Avatar`}
                      width={40}
                      height={40}
                      className="rounded-full flex-shrink-0 avatar"
                    />
                  </Link>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/profile/${comment.user.name}`}
                        className="font-medium hover:text-[#9b7e4b] transition-colors"
                      >
                        {comment.user.name}
                      </Link>
                      <span className="text-xs text-[#e8e0d0]/60">{comment.date}</span>
                    </div>
                    <p className="mt-1">{comment.text}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <button
                        className={`flex items-center gap-1 text-sm ${
                          comment.isLiked ? "text-[#9b7e4b]" : "text-[#e8e0d0]/60"
                        } hover:text-[#9b7e4b] transition-colors`}
                        onClick={() => handleCommentLike(comment.id)}
                      >
                        <Heart size={14} fill={comment.isLiked ? "currentColor" : "none"} />
                        <span>{comment.likes}</span>
                      </button>
                      <button className="text-sm text-[#e8e0d0]/60 hover:text-[#9b7e4b] transition-colors">
                        Responder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Columna lateral - Videos relacionados */}
        <div className="animate-fade-in">
          <h2 className="font-bold text-xl mb-4">Videos relacionados</h2>

          <div className="space-y-4">
            {relatedVideos.map((video) => (
              <Link key={video.id} href={`/video/${video.id}`} className="group block">
                <div className="flex gap-3">
                  <div className="w-40 h-24 flex-shrink-0 rounded overflow-hidden">
                    <div className="relative w-full h-full">
                      <Image
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-8 h-8 rounded-full bg-[#9b7e4b]/80 flex items-center justify-center">
                          <div className="w-0 h-0 border-t-4 border-t-transparent border-l-8 border-l-white border-b-4 border-b-transparent ml-0.5"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium line-clamp-2 group-hover:text-[#9b7e4b] transition-colors">
                      {video.title}
                    </p>
                    <Link
                      href={`/profile/${video.username}`}
                      className="text-sm text-[#e8e0d0]/60 hover:text-[#9b7e4b] transition-colors mt-1 block"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {video.username}
                    </Link>
                    <div className="flex items-center gap-2 text-xs text-[#e8e0d0]/60 mt-1">
                      <span>{video.views} vistas</span>
                      <span>•</span>
                      <span>{video.date}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
