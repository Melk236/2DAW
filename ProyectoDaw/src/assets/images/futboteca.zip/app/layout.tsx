import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"
import MobileNav from "@/components/mobile-nav"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Futboteca - Revive la historia del fútbol",
  description: "Red social para compartir y descubrir videos históricos de fútbol",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className={inter.className}>
        <div className="noise-bg"></div>
        <Navbar />
        {children}
        <MobileNav />
        <div className="pb-16 md:pb-0"></div>
      </body>
    </html>
  )
}
