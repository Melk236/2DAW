"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, MessageSquare, Eye, SearchIcon } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState("all")

  // Mock search results
  const searchResults = [
    {
      id: 1,
      title: "La 'Mano de Dios'- Maradona vs Inglaterra(1986)",
      thumbnail: "/placeholder.svg?height=180&width=320",
      category: "players",
      categoryName: "Jugadores legendarios",
      user: "Futboteca",
      userAvatar: "/placeholder.svg?height=30&width=30",
      views: "1.2M",
      likes: "45k",
      comments: "3.2k",
      date: "10/06/2023",
    },
    {
      id: 2,
      title: "Gol de Iniesta - España vs Holanda (2010)",
      thumbnail: "/placeholder.svg?height=180&width=320",
      category: "goals",
      categoryName: "Goles icónicos",
      user: "FutbolHistórico",
      userAvatar: "/placeholder.svg?height=30&width=30",
      views: "980k",
      likes: "38k",
      comments: "2.7k",
      date: "15/05/2023",
    },
    {
      id: 3,
      title: "Brasil vs Italia - Final Mundial 1994",
      thumbnail: "/placeholder.svg?height=180&width=320",
      category: "matches",
      categoryName: "Partidos memorables",
      user: "MundialHistoria",
      userAvatar: "/placeholder.svg?height=30&width=30",
      views: "850k",
      likes: "32k",
      comments: "1.8k",
      date: "22/04/2023",
    },
    {
      id: 4,
      title: "Zidane vs Brasil - Mundial 2006",
      thumbnail: "/placeholder.svg?height=180&width=320",
      category: "players",
      categoryName: "Jugadores legendarios",
      user: "LegendsFutbol",
      userAvatar: "/placeholder.svg?height=30&width=30",
      views: "720k",
      likes: "29k",
      comments: "1.5k",
      date: "05/03/2023",
    },
  ]

  // Filter results based on active filter
  const filteredResults =
    activeFilter === "all" ? searchResults : searchResults.filter((result) => result.category === activeFilter)

  return (
    <>
      <Navbar />
      <main style={{ paddingTop: "6rem", paddingBottom: "4rem" }} className="container mx-auto px-4">
        {/* Search Header */}
        <div className="mb-8">
          <div className="relative max-w-2xl mx-auto">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar videos, jugadores, competiciones..."
              className="w-full p-4 pl-12 rounded-lg"
              style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
            />
            <SearchIcon
              className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5"
              style={{ color: "rgba(232, 224, 208, 0.6)" }}
            />
          </div>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 justify-center">
            <button
              onClick={() => setActiveFilter("all")}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeFilter === "all" ? "#9b7e4b" : "transparent",
                color: "#e8e0d0",
                border: "1px solid " + (activeFilter === "all" ? "#9b7e4b" : "rgba(155, 126, 75, 0.3)"),
              }}
            >
              Todos
            </button>
            <button
              onClick={() => setActiveFilter("goals")}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeFilter === "goals" ? "#9b7e4b" : "transparent",
                color: "#e8e0d0",
                border: "1px solid " + (activeFilter === "goals" ? "#9b7e4b" : "rgba(155, 126, 75, 0.3)"),
              }}
            >
              Goles icónicos
            </button>
            <button
              onClick={() => setActiveFilter("matches")}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeFilter === "matches" ? "#9b7e4b" : "transparent",
                color: "#e8e0d0",
                border: "1px solid " + (activeFilter === "matches" ? "#9b7e4b" : "rgba(155, 126, 75, 0.3)"),
              }}
            >
              Partidos memorables
            </button>
            <button
              onClick={() => setActiveFilter("players")}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeFilter === "players" ? "#9b7e4b" : "transparent",
                color: "#e8e0d0",
                border: "1px solid " + (activeFilter === "players" ? "#9b7e4b" : "rgba(155, 126, 75, 0.3)"),
              }}
            >
              Jugadores legendarios
            </button>
            <button
              onClick={() => setActiveFilter("tournaments")}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeFilter === "tournaments" ? "#9b7e4b" : "transparent",
                color: "#e8e0d0",
                border: "1px solid " + (activeFilter === "tournaments" ? "#9b7e4b" : "rgba(155, 126, 75, 0.3)"),
              }}
            >
              Torneos históricos
            </button>
          </div>
        </div>

        {/* Search Results */}
        <div>
          <h2 className="text-2xl font-bold mb-6" style={{ color: "#e8e0d0" }}>
            Resultados de búsqueda
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredResults.map((result) => (
              <div key={result.id} className="video-card">
                <div className="relative pb-[56.25%] w-full rounded-t-lg overflow-hidden">
                  <Image
                    src={result.thumbnail || "/placeholder.svg"}
                    alt={result.title}
                    fill
                    className="object-cover"
                  />
                  <Link href={`/video/${result.id}`} className="absolute inset-0">
                    <span className="sr-only">Ver video</span>
                  </Link>
                </div>

                <div className="video-info">
                  <div className="text-start">
                    <span className="tag">{result.categoryName}</span>
                  </div>
                  <p className="font-bold text-lg text-start my-2 line-clamp-2" style={{ color: "#e8e0d0" }}>
                    {result.title}
                  </p>
                  <div className="flex gap-3 items-center text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                    <span className="flex items-center gap-1">
                      <Heart size={16} /> {result.likes}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare size={16} /> {result.comments}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye size={16} /> {result.views}
                    </span>
                    <span className="ml-auto">{result.date}</span>
                  </div>
                  <hr style={{ margin: "0.5rem 0", borderColor: "rgba(232, 224, 208, 0.1)" }} />
                  <div className="flex gap-3 items-center">
                    <Image
                      src={result.userAvatar || "/placeholder.svg"}
                      alt={`${result.user} Avatar`}
                      width={30}
                      height={30}
                      className="rounded-full"
                    />
                    <span style={{ color: "#e8e0d0" }}>{result.user}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredResults.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
                No se encontraron resultados para esta categoría
              </p>
              <button onClick={() => setActiveFilter("all")} className="btn-primary mt-4">
                Ver todos los videos
              </button>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}
