"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import VideoCard from "@/components/video-card"
import CategoryFilter from "@/components/category-filter"
import MatchTicker from "@/components/match-ticker"
import EraSelector from "@/components/era-selector"
import FootballQuiz from "@/components/football-quiz"
import StatsComparison from "@/components/stats-comparison"

// Datos de ejemplo
const featuredVideos = [
  {
    id: 1,
    title: "La 'Mano de Dios'- Maradona vs Inglaterra (1986)",
    username: "Futboteca",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "45k",
    comments: "3.2k",
    views: "1.2M",
    category: "players",
    categoryName: "Jugadores legendarios",
  },
  {
    id: 2,
    title: "Gol de Iniesta - España vs Holanda (2010)",
    username: "FutbolHistórico",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "38k",
    comments: "2.7k",
    views: "980k",
    category: "goals",
    categoryName: "Goles icónicos",
  },
  {
    id: 3,
    title: "Brasil vs Italia - Final Mundial 1994",
    username: "MundialHistoria",
    userAvatar: "/placeholder.svg?height=48&width=48",
    videoUrl: "https://www.youtube.com/embed/JqbEZJ5r0rk",
    likes: "32k",
    comments: "1.8k",
    views: "850k",
    category: "matches",
    categoryName: "Partidos memorables",
  },
]

const categories = [
  { id: "following", name: "Siguiendo" },
  { id: "goals", name: "Goles icónicos" },
  { id: "matches", name: "Partidos memorables" },
  { id: "players", name: "Jugadores legendarios" },
  { id: "tournaments", name: "Torneos históricos" },
  { id: "teams", name: "Equipos" },
  { id: "worldcup", name: "Mundiales" },
  { id: "champions", name: "Champions League" },
  { id: "euro", name: "Eurocopas" },
  { id: "libertadores", name: "Copa Libertadores" },
]

const historicMatches = [
  {
    id: 1,
    homeTeam: "Argentina",
    homeTeamLogo: "/placeholder.svg?height=30&width=30",
    awayTeam: "Inglaterra",
    awayTeamLogo: "/placeholder.svg?height=30&width=30",
    homeScore: 2,
    awayScore: 1,
    year: 1986,
    tournament: "Mundial",
    matchUrl: "/video/1",
  },
  {
    id: 2,
    homeTeam: "Brasil",
    homeTeamLogo: "/placeholder.svg?height=30&width=30",
    awayTeam: "Italia",
    awayTeamLogo: "/placeholder.svg?height=30&width=30",
    homeScore: 3,
    awayScore: 2,
    year: 1994,
    tournament: "Mundial",
    matchUrl: "/video/3",
  },
  {
    id: 3,
    homeTeam: "España",
    homeTeamLogo: "/placeholder.svg?height=30&width=30",
    awayTeam: "Holanda",
    awayTeamLogo: "/placeholder.svg?height=30&width=30",
    homeScore: 1,
    awayScore: 0,
    year: 2010,
    tournament: "Mundial",
    matchUrl: "/video/2",
  },
]

const quizQuestions = [
  {
    id: 1,
    question: "¿Quién ganó el Mundial de 1986?",
    options: ["Brasil", "Argentina", "Alemania", "Italia"],
    correctAnswer: 1,
  },
  {
    id: 2,
    question: "¿Cuántos Balones de Oro ha ganado Lionel Messi?",
    options: ["5", "6", "7", "8"],
    correctAnswer: 2,
  },
  {
    id: 3,
    question: "¿En qué año se jugó el primer Mundial de fútbol?",
    options: ["1926", "1930", "1934", "1938"],
    correctAnswer: 1,
  },
]

const eras = [
  { id: "1950s", year: "1950s", title: "Era Pelé" },
  { id: "1960s", year: "1960s", title: "Fútbol Total" },
  { id: "1970s", year: "1970s", title: "Brasil Dorado" },
  { id: "1980s", year: "1980s", title: "Era Maradona" },
  { id: "1990s", year: "1990s", title: "Ronaldo" },
  { id: "2000s", year: "2000s", title: "Zidane" },
  { id: "2010s", year: "2010s", title: "Messi vs CR7" },
  { id: "2020s", year: "2020s", title: "Nueva Era" },
]

const legendsComparison = {
  player1: {
    name: "Diego Maradona",
    image: "/placeholder.svg?height=96&width=96",
    stats: {
      goals: 345,
      assists: 174,
      matches: 680,
      trophies: 11,
      rating: 9.5,
    },
  },
  player2: {
    name: "Pelé",
    image: "/placeholder.svg?height=96&width=96",
    stats: {
      goals: 767,
      assists: 230,
      matches: 831,
      trophies: 26,
      rating: 9.8,
    },
  },
}

export default function Home() {
  const [activeTab, setActiveTab] = useState("for-you")
  const [activeCategory, setActiveCategory] = useState("all")
  const [activeEra, setActiveEra] = useState("1980s")
  const [videos, setVideos] = useState(featuredVideos)

  useEffect(() => {
    // Simular carga de videos basados en la categoría
    if (activeCategory === "all") {
      setVideos(featuredVideos)
    } else {
      setVideos(featuredVideos.filter((video) => video.category === activeCategory || activeCategory === "following"))
    }
  }, [activeCategory])

  return (
    <main className="pt-16">
      {/* Ticker de partidos históricos */}
      <div className="py-2 px-4">
        <MatchTicker matches={historicMatches} />
      </div>

      {/* Tabs de navegación */}
      <div className="flex justify-center border-b border-[#9b7e4b]/20">
        <button className={`tab ${activeTab === "for-you" ? "active" : ""}`} onClick={() => setActiveTab("for-you")}>
          Para ti
        </button>
        <button
          className={`tab ${activeTab === "following" ? "active" : ""}`}
          onClick={() => {
            setActiveTab("following")
            setActiveCategory("following")
          }}
        >
          Siguiendo
        </button>
      </div>

      <div className="py-4 px-4 text-center text-sm text-[#e8e0d0]/70">
        {activeTab === "for-you"
          ? "Videos recomendados para ti basados en tus intereses"
          : "Videos de las personas que sigues"}
      </div>

      {/* Filtro de categorías */}
      <CategoryFilter categories={categories} activeCategory={activeCategory} onChange={setActiveCategory} />

      {/* Contenido principal */}
      <div className="container mx-auto px-4 py-6">
        {/* Sección de destacados */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gradient">Momentos Destacados</h2>
            <Link href="/explore" className="text-[#9b7e4b] hover:underline text-sm font-medium">
              Ver todos
            </Link>
          </div>

          {/* Banner interactivo */}
          <div className="interactive-banner mb-8 h-[300px] md:h-[400px]">
            <Image
              src="/placeholder.svg?height=400&width=1200"
              alt="Mundial 1986"
              fill
              className="object-cover rounded-lg"
            />
            <div className="content">
              <span className="tag mb-2">Momentos Históricos</span>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">Mundial México 1986</h2>
              <p className="mb-4 text-[#e8e0d0]/80">
                Revive el torneo que consagró a Diego Armando Maradona como leyenda del fútbol mundial
              </p>
              <Link href="/tournaments/mundial/1986" className="btn-primary inline-block">
                Explorar Mundial 1986
              </Link>
            </div>
          </div>

          {/* Videos destacados */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <VideoCard key={video.id} {...video} />
            ))}
          </div>
        </div>

        {/* Sección de épocas */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gradient mb-6">Viaje en el Tiempo</h2>

          <EraSelector eras={eras} activeEra={activeEra} onChange={setActiveEra} />

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card p-6">
              <h3 className="text-xl font-bold mb-4">Era Maradona: Los 80s</h3>
              <p className="mb-4 text-[#e8e0d0]/80">
                La década de 1980 estuvo marcada por el surgimiento de Diego Armando Maradona como la figura más
                dominante del fútbol mundial. Su actuación en el Mundial de México 1986 es considerada una de las
                mejores de la historia.
              </p>
              <div className="timeline">
                <div className="timeline-item">
                  <span className="timeline-date">1982</span>
                  <h4 className="font-bold">Mundial España</h4>
                  <p className="text-sm text-[#e8e0d0]/70">Italia se corona campeón del mundo por tercera vez</p>
                </div>
                <div className="timeline-item">
                  <span className="timeline-date">1986</span>
                  <h4 className="font-bold">Mundial México</h4>
                  <p className="text-sm text-[#e8e0d0]/70">
                    Argentina gana su segundo título mundial liderada por Maradona
                  </p>
                </div>
                <div className="timeline-item">
                  <span className="timeline-date">1988</span>
                  <h4 className="font-bold">Eurocopa</h4>
                  <p className="text-sm text-[#e8e0d0]/70">Holanda gana su primer título europeo con Van Basten</p>
                </div>
              </div>
              <div className="mt-4">
                <Link href="/eras/1980s" className="btn-primary">
                  Explorar los 80s
                </Link>
              </div>
            </div>

            <div className="relative">
              <div className="retro-tv">
                <div className="retro-tv-content">
                  <iframe
                    src="https://www.youtube.com/embed/JqbEZJ5r0rk?autoplay=0"
                    title="Maradona - Gol del Siglo"
                    className="w-full h-full"
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="retro-tv-knobs">
                  <div className="retro-tv-knob"></div>
                  <div className="retro-tv-knob"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sección interactiva */}
        <div className="mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Quiz de fútbol */}
            <FootballQuiz questions={quizQuestions} />

            {/* Comparación de leyendas */}
            <StatsComparison player1={legendsComparison.player1} player2={legendsComparison.player2} />
          </div>
        </div>

        {/* Sección de estadísticas */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gradient mb-6">Estadísticas Históricas</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="stat-card">
              <div className="stat-number">21</div>
              <h3 className="font-bold">Mundiales</h3>
              <p className="text-sm text-[#e8e0d0]/70">Torneos disputados desde 1930</p>
            </div>

            <div className="stat-card">
              <div className="stat-number">5</div>
              <h3 className="font-bold">Brasil</h3>
              <p className="text-sm text-[#e8e0d0]/70">País con más títulos mundiales</p>
            </div>

            <div className="stat-card">
              <div className="stat-number">16</div>
              <h3 className="font-bold">Miroslav Klose</h3>
              <p className="text-sm text-[#e8e0d0]/70">Máximo goleador en Mundiales</p>
            </div>

            <div className="stat-card">
              <div className="stat-number">8</div>
              <h3 className="font-bold">Balones de Oro</h3>
              <p className="text-sm text-[#e8e0d0]/70">Récord de Lionel Messi</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
