import Image from "next/image"
import { Bell, Heart, MessageSquare, UserPlus } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function Notifications() {
  // Mock notifications data
  const notifications = [
    {
      id: 1,
      type: "like",
      user: {
        name: "Carlos Martínez",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "le ha dado like a tu video",
      video: {
        title: "La 'Mano de Dios'- Maradona vs Inglaterra(1986)",
        thumbnail: "/placeholder.svg?height=60&width=100",
      },
      time: "hace 5 minutos",
      isRead: false,
    },
    {
      id: 2,
      type: "comment",
      user: {
        name: "Laura Sánchez",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "ha comentado en tu video",
      video: {
        title: "Gol de Iniesta - España vs Holanda (2010)",
        thumbnail: "/placeholder.svg?height=60&width=100",
      },
      time: "hace 2 horas",
      isRead: false,
    },
    {
      id: 3,
      type: "follow",
      user: {
        name: "Miguel Rodríguez",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "ha comenzado a seguirte",
      time: "hace 1 día",
      isRead: true,
    },
    {
      id: 4,
      type: "like",
      user: {
        name: "Ana García",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "le ha dado like a tu video",
      video: {
        title: "Brasil vs Italia - Final Mundial 1994",
        thumbnail: "/placeholder.svg?height=60&width=100",
      },
      time: "hace 2 días",
      isRead: true,
    },
    {
      id: 5,
      type: "comment",
      user: {
        name: "Javier López",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "ha comentado en tu video",
      video: {
        title: "Zidane vs Brasil - Mundial 2006",
        thumbnail: "/placeholder.svg?height=60&width=100",
      },
      time: "hace 3 días",
      isRead: true,
    },
  ]

  // Function to render icon based on notification type
  const renderIcon = (type: string) => {
    switch (type) {
      case "like":
        return <Heart className="h-5 w-5" style={{ color: "#9b7e4b" }} />
      case "comment":
        return <MessageSquare className="h-5 w-5" style={{ color: "#9b7e4b" }} />
      case "follow":
        return <UserPlus className="h-5 w-5" style={{ color: "#9b7e4b" }} />
      default:
        return <Bell className="h-5 w-5" style={{ color: "#9b7e4b" }} />
    }
  }

  return (
    <>
      <Navbar />
      <main style={{ paddingTop: "6rem", paddingBottom: "4rem" }} className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold" style={{ color: "#e8e0d0" }}>
              Notificaciones
            </h1>
            <button className="text-sm" style={{ color: "#9b7e4b" }}>
              Marcar todas como leídas
            </button>
          </div>

          <div className="space-y-4">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="p-4 rounded-lg"
                style={{
                  backgroundColor: notification.isRead ? "rgba(20, 16, 12, 0.5)" : "rgba(155, 126, 75, 0.1)",
                  border: "1px solid rgba(155, 126, 75, 0.2)",
                }}
              >
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    <Image
                      src={notification.user.avatar || "/placeholder.svg"}
                      alt={notification.user.name}
                      width={48}
                      height={48}
                      className="rounded-full"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium" style={{ color: "#e8e0d0" }}>
                        {notification.user.name}
                      </span>
                      <span style={{ color: "rgba(232, 224, 208, 0.7)" }}>{notification.content}</span>
                    </div>
                    {notification.video && (
                      <div className="mt-2 flex items-center gap-3">
                        <div className="flex-shrink-0 w-[60px] h-[40px] rounded overflow-hidden">
                          <Image
                            src={notification.video.thumbnail || "/placeholder.svg"}
                            alt={notification.video.title}
                            width={60}
                            height={40}
                            className="object-cover w-full h-full"
                          />
                        </div>
                        <p className="text-sm line-clamp-1" style={{ color: "#e8e0d0" }}>
                          {notification.video.title}
                        </p>
                      </div>
                    )}
                    <p className="text-xs mt-1" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                      {notification.time}
                    </p>
                  </div>
                  <div className="flex-shrink-0">{renderIcon(notification.type)}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <button className="btn-primary">Cargar más notificaciones</button>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
