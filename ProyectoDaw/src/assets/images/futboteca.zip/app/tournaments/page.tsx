"use client"

import { useState } from "react"
import Image from "next/image"
import { Trophy, Calendar, MapPin, Star } from "lucide-react"
import TournamentBracket from "@/components/tournament-bracket"

// Datos de ejemplo
const tournaments = [
  {
    id: "mundial-1986",
    name: "Copa Mundial",
    year: 1986,
    location: "México",
    winner: "Argentina",
    runnerUp: "Alemania",
    image: "/placeholder.svg?height=300&width=500",
    icon: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "mundial-1994",
    name: "Copa Mundial",
    year: 1994,
    location: "Estados Unidos",
    winner: "Brasil",
    runnerUp: "Italia",
    image: "/placeholder.svg?height=300&width=500",
    icon: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "champions-2005",
    name: "Champions League",
    year: 2005,
    location: "Estambul",
    winner: "Liverpool",
    runnerUp: "Milan",
    image: "/placeholder.svg?height=300&width=500",
    icon: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "euro-2008",
    name: "Eurocopa",
    year: 2008,
    location: "Austria/Suiza",
    winner: "España",
    runnerUp: "Alemania",
    image: "/placeholder.svg?height=300&width=500",
    icon: "/placeholder.svg?height=60&width=60",
  },
]

const worldCup1986Rounds = [
  {
    name: "Cuartos de Final",
    matches: [
      {
        id: 1,
        homeTeam: { id: 1, name: "Argentina", logo: "/placeholder.svg?height=24&width=24" },
        awayTeam: { id: 2, name: "Inglaterra", logo: "/placeholder.svg?height=24&width=24" },
        homeScore: 2,
        awayScore: 1,
        winner: "home",
        matchUrl: "/video/1",
      },
      {
        id: 2,
        homeTeam: { id: 3, name: "Alemania", logo: "/placeholder.svg?height=24&width=24" },
        awayTeam: { id: 4, name: "México", logo: "/placeholder.svg?height=24&width=24" },
        homeScore: 0,
        awayScore: 0,
        winner: "home",
        matchUrl: "/video/4",
      },
    ],
  },
  {
    name: "Semifinales",
    matches: [
      {
        id: 3,
        homeTeam: { id: 1, name: "Argentina", logo: "/placeholder.svg?height=24&width=24" },
        awayTeam: { id: 5, name: "Bélgica", logo: "/placeholder.svg?height=24&width=24" },
        homeScore: 2,
        awayScore: 0,
        winner: "home",
        matchUrl: "/video/5",
      },
      {
        id: 4,
        homeTeam: { id: 3, name: "Alemania", logo: "/placeholder.svg?height=24&width=24" },
        awayTeam: { id: 6, name: "Francia", logo: "/placeholder.svg?height=24&width=24" },
        homeScore: 2,
        awayScore: 0,
        winner: "home",
        matchUrl: "/video/6",
      },
    ],
  },
  {
    name: "Final",
    matches: [
      {
        id: 5,
        homeTeam: { id: 1, name: "Argentina", logo: "/placeholder.svg?height=24&width=24" },
        awayTeam: { id: 3, name: "Alemania", logo: "/placeholder.svg?height=24&width=24" },
        homeScore: 3,
        awayScore: 2,
        winner: "home",
        matchUrl: "/video/7",
      },
    ],
  },
]

export default function TournamentsPage() {
  const [selectedTournament, setSelectedTournament] = useState(tournaments[0])
  const [activeTab, setActiveTab] = useState("info")

  return (
    <main className="pt-20 pb-16 container mx-auto px-4">
      <h1 className="text-3xl font-bold mb-6 text-gradient">Torneos Históricos</h1>

      {/* Selector de torneos */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-8">
        {tournaments.map((tournament) => (
          <div
            key={tournament.id}
            className={`card p-4 cursor-pointer transition-all ${
              selectedTournament.id === tournament.id ? "border-[#9b7e4b] bg-[#9b7e4b]/10" : "hover:border-[#9b7e4b]/60"
            }`}
            onClick={() => setSelectedTournament(tournament)}
          >
            <div className="flex items-center gap-3">
              <Image
                src={tournament.icon || "/placeholder.svg"}
                alt={tournament.name}
                width={40}
                height={40}
                className="rounded-full"
              />
              <div>
                <h3 className="font-bold">{tournament.name}</h3>
                <p className="text-sm text-[#e8e0d0]/70">{tournament.year}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Detalle del torneo */}
      <div className="animate-fade-in">
        <div className="interactive-banner mb-8 h-[300px]">
          <Image
            src={selectedTournament.image || "/placeholder.svg"}
            alt={`${selectedTournament.name} ${selectedTournament.year}`}
            fill
            className="object-cover rounded-lg"
          />
          <div className="content">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">
              {selectedTournament.name} {selectedTournament.year}
            </h2>
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Trophy className="h-4 w-4 text-[#d4af37]" />
                <span>Campeón: {selectedTournament.winner}</span>
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-[#9b7e4b]" />
                <span>Subcampeón: {selectedTournament.runnerUp}</span>
              </div>
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4 text-[#9b7e4b]" />
                <span>Sede: {selectedTournament.location}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4 text-[#9b7e4b]" />
                <span>Año: {selectedTournament.year}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-[#9b7e4b]/20 mb-6">
          <div className="flex">
            <button className={`tab ${activeTab === "info" ? "active" : ""}`} onClick={() => setActiveTab("info")}>
              Información
            </button>
            <button
              className={`tab ${activeTab === "bracket" ? "active" : ""}`}
              onClick={() => setActiveTab("bracket")}
            >
              Cuadro
            </button>
            <button className={`tab ${activeTab === "videos" ? "active" : ""}`} onClick={() => setActiveTab("videos")}>
              Videos
            </button>
          </div>
        </div>

        {/* Contenido de las tabs */}
        {activeTab === "info" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card p-6">
              <h3 className="text-xl font-bold mb-4">Datos del Torneo</h3>
              <p className="mb-4">
                El Mundial de México 1986 es recordado como el torneo de Diego Maradona, quien llevó a Argentina a su
                segundo título mundial con actuaciones legendarias, incluyendo la famosa "Mano de Dios" y el "Gol del
                Siglo" contra Inglaterra en cuartos de final.
              </p>
              <p>
                El torneo contó con 24 equipos y se disputaron 52 partidos, con un total de 132 goles (promedio de 2.54
                por partido). El máximo goleador fue Gary Lineker de Inglaterra con 6 goles.
              </p>
            </div>

            <div className="card p-6">
              <h3 className="text-xl font-bold mb-4">Estadísticas</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Partidos jugados</span>
                    <span>52</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: "100%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Goles anotados</span>
                    <span>132</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: "80%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Promedio de goles</span>
                    <span>2.54</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: "65%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Tarjetas amarillas</span>
                    <span>136</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: "70%" }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Tarjetas rojas</span>
                    <span>8</span>
                  </div>
                  <div className="progress-bar">
                    <div className="progress-bar-fill" style={{ width: "20%" }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "bracket" && <TournamentBracket rounds={worldCup1986Rounds} title="Copa Mundial" year={1986} />}

        {activeTab === "videos" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="card overflow-hidden">
              <div className="relative pb-[56.25%]">
                <iframe
                  src="https://www.youtube.com/embed/JqbEZJ5r0rk"
                  title="La Mano de Dios"
                  className="absolute top-0 left-0 w-full h-full"
                  allowFullScreen
                ></iframe>
              </div>
              <div className="p-4">
                <h3 className="font-bold">La Mano de Dios</h3>
                <p className="text-sm text-[#e8e0d0]/70">Argentina vs Inglaterra - Cuartos de Final</p>
              </div>
            </div>
            <div className="card overflow-hidden">
              <div className="relative pb-[56.25%]">
                <iframe
                  src="https://www.youtube.com/embed/JqbEZJ5r0rk"
                  title="El Gol del Siglo"
                  className="absolute top-0 left-0 w-full h-full"
                  allowFullScreen
                ></iframe>
              </div>
              <div className="p-4">
                <h3 className="font-bold">El Gol del Siglo</h3>
                <p className="text-sm text-[#e8e0d0]/70">Argentina vs Inglaterra - Cuartos de Final</p>
              </div>
            </div>
            <div className="card overflow-hidden">
              <div className="relative pb-[56.25%]">
                <iframe
                  src="https://www.youtube.com/embed/JqbEZJ5r0rk"
                  title="Final Mundial 1986"
                  className="absolute top-0 left-0 w-full h-full"
                  allowFullScreen
                ></iframe>
              </div>
              <div className="p-4">
                <h3 className="font-bold">Final Mundial 1986</h3>
                <p className="text-sm text-[#e8e0d0]/70">Argentina vs Alemania - Final</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
