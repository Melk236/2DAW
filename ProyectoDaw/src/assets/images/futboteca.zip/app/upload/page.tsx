"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Upload, AlertCircle } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function UploadVideo() {
  const router = useRouter()
  const [videoUrl, setVideoUrl] = useState("")
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [tags, setTags] = useState("")
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [previewUrl, setPreviewUrl] = useState("")

  // Function to extract YouTube video ID
  const extractYouTubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/
    const match = url.match(regExp)
    return match && match[2].length === 11 ? match[2] : null
  }

  // Handle video URL change
  const handleVideoUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value
    setVideoUrl(url)

    // Generate preview if valid YouTube URL
    const videoId = extractYouTubeId(url)
    if (videoId) {
      setPreviewUrl(`https://www.youtube.com/embed/${videoId}`)
      setError("")
    } else if (url) {
      setPreviewUrl("")
      setError("Por favor, introduce una URL válida de YouTube")
    } else {
      setPreviewUrl("")
      setError("")
    }
  }

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!videoUrl || !title || !category) {
      setError("Por favor, completa todos los campos obligatorios")
      return
    }

    // Validate YouTube URL
    const videoId = extractYouTubeId(videoUrl)
    if (!videoId) {
      setError("Por favor, introduce una URL válida de YouTube")
      return
    }

    // Submit form
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      // Redirect to video page
      router.push("/feed")
    }, 1500)
  }

  return (
    <>
      <Navbar />
      <main style={{ paddingTop: "6rem", paddingBottom: "4rem" }} className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-6" style={{ color: "#e8e0d0" }}>
            Subir Video
          </h1>

          {error && (
            <div
              className="rounded-lg p-4 mb-6 flex items-start gap-3"
              style={{ backgroundColor: "rgba(220, 38, 38, 0.1)", border: "1px solid rgba(220, 38, 38, 0.5)" }}
            >
              <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" style={{ color: "#ef4444" }} />
              <p style={{ color: "#ef4444" }}>{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Video URL */}
            <div className="space-y-2">
              <label htmlFor="videoUrl" className="block font-medium" style={{ color: "#e8e0d0" }}>
                URL del Video <span style={{ color: "#ef4444" }}>*</span>
              </label>
              <input
                id="videoUrl"
                type="url"
                value={videoUrl}
                onChange={handleVideoUrlChange}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
              <p className="text-sm" style={{ color: "rgba(232, 224, 208, 0.6)" }}>
                Introduce la URL de un video de YouTube público
              </p>
            </div>

            {/* Video Preview */}
            {previewUrl && (
              <div
                className="relative pb-[56.25%] w-full rounded-lg overflow-hidden"
                style={{ border: "1px solid rgba(155, 126, 75, 0.3)" }}
              >
                <iframe
                  src={previewUrl}
                  title="Video Preview"
                  className="absolute top-0 left-0 w-full h-full"
                  allowFullScreen
                ></iframe>
              </div>
            )}

            {/* Title */}
            <div className="space-y-2">
              <label htmlFor="title" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Título <span style={{ color: "#ef4444" }}>*</span>
              </label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Título del video"
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              />
            </div>

            {/* Category */}
            <div className="space-y-2">
              <label htmlFor="category" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Categoría <span style={{ color: "#ef4444" }}>*</span>
              </label>
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
                required
              >
                <option value="">Selecciona una categoría</option>
                <option value="goals">Goles icónicos</option>
                <option value="matches">Partidos memorables</option>
                <option value="players">Jugadores legendarios</option>
                <option value="tournaments">Torneos históricos</option>
              </select>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <label htmlFor="tags" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Etiquetas
              </label>
              <input
                id="tags"
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="Separa las etiquetas con comas (ej: mundial, 1986, maradona)"
                className="w-full p-3 rounded-lg"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label htmlFor="description" className="block font-medium" style={{ color: "#e8e0d0" }}>
                Descripción
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe el video..."
                rows={4}
                className="w-full p-3 rounded-lg resize-none"
                style={{ backgroundColor: "#14100c", color: "#e8e0d0", border: "1px solid rgba(155, 126, 75, 0.3)" }}
              ></textarea>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div
                      className="h-5 w-5 rounded-full animate-spin"
                      style={{ border: "2px solid rgba(232, 224, 208, 0.2)", borderTopColor: "#e8e0d0" }}
                    ></div>
                    <span>Subiendo...</span>
                  </>
                ) : (
                  <>
                    <Upload className="h-5 w-5" />
                    <span>Subir Video</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </>
  )
}
