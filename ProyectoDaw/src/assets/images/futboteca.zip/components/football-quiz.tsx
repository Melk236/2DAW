"use client"

import { useState } from "react"
import { CheckCircle, XCircle } from "lucide-react"

interface QuizQuestion {
  id: number
  question: string
  options: string[]
  correctAnswer: number
}

interface FootballQuizProps {
  questions: QuizQuestion[]
  onComplete?: (score: number) => void
}

export default function FootballQuiz({ questions, onComplete }: FootballQuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [isAnswered, setIsAnswered] = useState(false)
  const [score, setScore] = useState(0)
  const [quizCompleted, setQuizCompleted] = useState(false)

  const currentQuestion = questions[currentQuestionIndex]

  const handleOptionSelect = (optionIndex: number) => {
    if (isAnswered) return

    setSelectedOption(optionIndex)
    setIsAnswered(true)

    if (optionIndex === currentQuestion.correctAnswer) {
      setScore(score + 1)
    }

    // Avanzar a la siguiente pregunta después de un breve retraso
    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
        setSelectedOption(null)
        setIsAnswered(false)
      } else {
        setQuizCompleted(true)
        if (onComplete) {
          onComplete(score + (optionIndex === currentQuestion.correctAnswer ? 1 : 0))
        }
      }
    }, 1500)
  }

  const getOptionClassName = (optionIndex: number) => {
    if (!isAnswered) {
      return selectedOption === optionIndex ? "quiz-option selected" : "quiz-option"
    }

    if (optionIndex === currentQuestion.correctAnswer) {
      return "quiz-option correct"
    }

    if (selectedOption === optionIndex) {
      return "quiz-option incorrect"
    }

    return "quiz-option"
  }

  if (quizCompleted) {
    return (
      <div className="quiz-card animate-fade-in">
        <h3 className="text-xl font-bold mb-4">¡Quiz completado!</h3>
        <p className="mb-4">
          Tu puntuación: <span className="text-[#d4af37] font-bold">{score}</span> de {questions.length}
        </p>
        <div className="flex justify-center">
          <button
            className="btn-primary"
            onClick={() => {
              setCurrentQuestionIndex(0)
              setSelectedOption(null)
              setIsAnswered(false)
              setScore(0)
              setQuizCompleted(false)
            }}
          >
            Intentar de nuevo
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="quiz-card animate-fade-in">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold">Trivia de Fútbol</h3>
        <span className="text-sm text-[#e8e0d0]/70">
          Pregunta {currentQuestionIndex + 1} de {questions.length}
        </span>
      </div>

      <div className="progress-bar mb-4">
        <div
          className="progress-bar-fill"
          style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
        ></div>
      </div>

      <p className="text-lg mb-6">{currentQuestion.question}</p>

      <div className="space-y-3">
        {currentQuestion.options.map((option, index) => (
          <div key={index} className={getOptionClassName(index)} onClick={() => handleOptionSelect(index)}>
            <div className="flex justify-between items-center">
              <span>{option}</span>
              {isAnswered && index === currentQuestion.correctAnswer && (
                <CheckCircle className="h-5 w-5 text-green-500" />
              )}
              {isAnswered && index === selectedOption && index !== currentQuestion.correctAnswer && (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
