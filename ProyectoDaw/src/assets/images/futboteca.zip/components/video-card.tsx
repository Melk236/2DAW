"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, MessageSquare, Share2, BookmarkPlus } from "lucide-react"

interface VideoCardProps {
  id: number
  title: string
  username: string
  userAvatar: string
  thumbnail?: string
  videoUrl: string
  likes: string
  comments: string
  views: string
  category: string
  categoryName: string
  date?: string
  fullHeight?: boolean
}

export default function VideoCard({
  id,
  title,
  username,
  userAvatar,
  thumbnail,
  videoUrl,
  likes,
  comments,
  views,
  category,
  categoryName,
  date,
  fullHeight = false,
}: VideoCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsLiked(!isLiked)
  }

  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsSaved(!isSaved)
  }

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    // Implementar compartir
  }

  return (
    <div
      className={`video-card ${fullHeight ? "h-full" : ""} animate-fade-in`}
      style={fullHeight ? { height: "calc(100vh - 64px)" } : {}}
    >
      {/* Video o Thumbnail */}
      <div className={`relative ${fullHeight ? "h-full" : "pb-[56.25%]"} w-full overflow-hidden`}>
        {isPlaying || fullHeight ? (
          <iframe
            src={`${videoUrl}?autoplay=${fullHeight ? 1 : 0}&mute=${fullHeight ? 0 : 1}`}
            title={title}
            className="absolute top-0 left-0 w-full h-full"
            allowFullScreen
            allow="autoplay"
          ></iframe>
        ) : (
          <div className="absolute top-0 left-0 w-full h-full cursor-pointer" onClick={() => setIsPlaying(true)}>
            <Image
              src={thumbnail || "/placeholder.svg?height=720&width=1280"}
              alt={title}
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-[#9b7e4b]/80 flex items-center justify-center">
                <div className="w-0 h-0 border-t-8 border-t-transparent border-l-16 border-l-white border-b-8 border-b-transparent ml-1"></div>
              </div>
            </div>
          </div>
        )}

        {/* Acciones del video */}
        <div className="video-actions">
          <Link href={`/profile/${username}`} onClick={(e) => e.stopPropagation()}>
            <div className="avatar w-12 h-12 hover-scale">
              <Image
                src={userAvatar || "/placeholder.svg"}
                alt={username}
                width={48}
                height={48}
                className="rounded-full object-cover"
              />
            </div>
          </Link>
          <button
            className={`btn-icon ${isLiked ? "active animate-pulse" : ""}`}
            onClick={handleLike}
            aria-label="Me gusta"
          >
            <Heart className="h-6 w-6" fill={isLiked ? "currentColor" : "none"} />
          </button>
          <Link
            href={`/video/${id}`}
            onClick={(e) => e.stopPropagation()}
            className="btn-icon"
            aria-label="Comentarios"
          >
            <MessageSquare className="h-6 w-6" />
          </Link>
          <button className="btn-icon" onClick={handleShare} aria-label="Compartir">
            <Share2 className="h-6 w-6" />
          </button>
          <button
            className={`btn-icon ${isSaved ? "active" : ""}`}
            onClick={handleSave}
            aria-label="Guardar en favoritos"
          >
            <BookmarkPlus className="h-6 w-6" fill={isSaved ? "currentColor" : "none"} />
          </button>
        </div>

        {/* Información del video */}
        <div className="video-card-overlay">
          <Link href={`/categories/${category}`} className="tag mb-2 hover-scale inline-block">
            {categoryName}
          </Link>
          <h3 className="font-bold text-lg line-clamp-2 mb-1">{title}</h3>
          <div className="flex items-center justify-between">
            <Link
              href={`/profile/${username}`}
              className="flex items-center gap-2"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={userAvatar || "/placeholder.svg"}
                alt={username}
                width={24}
                height={24}
                className="rounded-full"
              />
              <span className="text-sm font-medium">{username}</span>
            </Link>
            <div className="flex items-center gap-3 text-xs text-[#e8e0d0]/70">
              <span className="flex items-center gap-1">
                <Heart size={12} /> {likes}
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare size={12} /> {comments}
              </span>
              {date && <span>{date}</span>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
