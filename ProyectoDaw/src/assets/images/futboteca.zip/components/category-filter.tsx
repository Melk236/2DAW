"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Category {
  id: string
  name: string
  icon?: string
}

interface CategoryFilterProps {
  categories: Category[]
  activeCategory: string
  onChange: (categoryId: string) => void
}

export default function CategoryFilter({ categories, activeCategory, onChange }: CategoryFilterProps) {
  const [scrollPosition, setScrollPosition] = useState(0)

  const scrollLeft = () => {
    const container = document.getElementById("category-container")
    if (container) {
      const newPosition = Math.max(scrollPosition - 200, 0)
      container.scrollTo({ left: newPosition, behavior: "smooth" })
      setScrollPosition(newPosition)
    }
  }

  const scrollRight = () => {
    const container = document.getElementById("category-container")
    if (container) {
      const newPosition = Math.min(scrollPosition + 200, container.scrollWidth - container.clientWidth)
      container.scrollTo({ left: newPosition, behavior: "smooth" })
      setScrollPosition(newPosition)
    }
  }

  return (
    <div className="relative">
      <button
        onClick={scrollLeft}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 btn-icon bg-[#14100c]/80"
        aria-label="Desplazar a la izquierda"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <div
        id="category-container"
        className="flex gap-2 py-2 px-8 overflow-x-auto hide-scrollbar scroll-smooth"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        <button
          onClick={() => onChange("all")}
          className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
            activeCategory === "all"
              ? "bg-[#9b7e4b] text-[#e8e0d0] shadow-gold"
              : "border border-[#9b7e4b]/30 text-[#e8e0d0] hover:bg-[#9b7e4b]/20"
          }`}
        >
          Todos
        </button>

        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onChange(category.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
              activeCategory === category.id
                ? "bg-[#9b7e4b] text-[#e8e0d0] shadow-gold"
                : "border border-[#9b7e4b]/30 text-[#e8e0d0] hover:bg-[#9b7e4b]/20"
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      <button
        onClick={scrollRight}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 btn-icon bg-[#14100c]/80"
        aria-label="Desplazar a la derecha"
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  )
}
