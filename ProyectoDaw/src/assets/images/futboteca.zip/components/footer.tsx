"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

export default function Footer() {
  const pathname = usePathname()

  // Skip footer on login and register pages
  if (pathname === "/login" || pathname === "/register") {
    return null
  }

  return (
    <footer style={{ backgroundColor: "#14100c", borderTop: "1px solid rgba(155, 126, 75, 0.2)", padding: "2rem 0" }}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4" style={{ color: "#e8e0d0" }}>
              FUTBOTECA
            </h3>
            <p className="text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
              La plataforma definitiva para revivir los momentos más inolvidables que marcaron la historia del fútbol
              mundial.
            </p>
          </div>

          <div>
            <h4 className="text-md font-bold mb-4" style={{ color: "#e8e0d0" }}>
              Explorar
            </h4>
            <ul className="space-y-2">
              <li>
                <Link href="/categories/goals" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Goles Icónicos
                </Link>
              </li>
              <li>
                <Link href="/categories/matches" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Partidos Memorables
                </Link>
              </li>
              <li>
                <Link href="/categories/players" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Jugadores Legendarios
                </Link>
              </li>
              <li>
                <Link
                  href="/categories/tournaments"
                  className="text-sm hover:text-primary"
                  style={{ color: "#e8e0d0" }}
                >
                  Torneos Históricos
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-md font-bold mb-4" style={{ color: "#e8e0d0" }}>
              Comunidad
            </h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Sobre Nosotros
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Preguntas Frecuentes
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-md font-bold mb-4" style={{ color: "#e8e0d0" }}>
              Legal
            </h4>
            <ul className="space-y-2">
              <li>
                <Link href="/terms" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Términos de Servicio
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link href="/cookies" className="text-sm hover:text-primary" style={{ color: "#e8e0d0" }}>
                  Política de Cookies
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div
          style={{
            borderTop: "1px solid rgba(155, 126, 75, 0.2)",
            marginTop: "2rem",
            paddingTop: "2rem",
            textAlign: "center",
          }}
        >
          <p className="text-sm" style={{ color: "rgba(232, 224, 208, 0.7)" }}>
            © {new Date().getFullYear()} Futboteca. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
