"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Compass, Upload, User } from "lucide-react"
import { Calendar } from "lucide-react"

export default function MobileNav() {
  const pathname = usePathname()

  // Skip navbar on login and register pages
  if (pathname === "/login" || pathname === "/register") {
    return null
  }

  // Check if link is active
  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden glass-effect border-t border-[#9b7e4b]/20">
      <div className="flex justify-around items-center py-2">
        <Link href="/" className="flex flex-col items-center py-1">
          <div className={`p-1 rounded-full ${isActive("/") ? "bg-[#9b7e4b]/20" : ""}`}>
            <Home className={`h-6 w-6 ${isActive("/") ? "text-[#9b7e4b]" : "text-[#e8e0d0]"}`} />
          </div>
          <span className={`text-xs mt-1 ${isActive("/") ? "text-[#9b7e4b]" : "text-[#e8e0d0]/70"}`}>Inicio</span>
        </Link>

        <Link href="/explore" className="flex flex-col items-center py-1">
          <div className={`p-1 rounded-full ${isActive("/explore") ? "bg-[#9b7e4b]/20" : ""}`}>
            <Compass className={`h-6 w-6 ${isActive("/explore") ? "text-[#9b7e4b]" : "text-[#e8e0d0]"}`} />
          </div>
          <span className={`text-xs mt-1 ${isActive("/explore") ? "text-[#9b7e4b]" : "text-[#e8e0d0]/70"}`}>
            Explorar
          </span>
        </Link>

        <Link href="/upload" className="flex flex-col items-center py-1">
          <div
            className={`p-3 rounded-full ${isActive("/upload") ? "bg-[#9b7e4b] shadow-gold" : "bg-[#9b7e4b]/20"} -mt-6`}
          >
            <Upload className={`h-6 w-6 ${isActive("/upload") ? "text-[#14100c]" : "text-[#9b7e4b]"}`} />
          </div>
          <span className={`text-xs mt-1 ${isActive("/upload") ? "text-[#9b7e4b]" : "text-[#e8e0d0]/70"}`}>Subir</span>
        </Link>

        <Link href="/eras" className="flex flex-col items-center py-1">
          <div className={`p-1 rounded-full ${isActive("/eras") ? "bg-[#9b7e4b]/20" : ""}`}>
            <Calendar className={`h-6 w-6 ${isActive("/eras") ? "text-[#9b7e4b]" : "text-[#e8e0d0]"}`} />
          </div>
          <span className={`text-xs mt-1 ${isActive("/eras") ? "text-[#9b7e4b]" : "text-[#e8e0d0]/70"}`}>Épocas</span>
        </Link>

        <Link href="/profile" className="flex flex-col items-center py-1">
          <div className={`p-1 rounded-full ${isActive("/profile") ? "bg-[#9b7e4b]/20" : ""}`}>
            <User className={`h-6 w-6 ${isActive("/profile") ? "text-[#9b7e4b]" : "text-[#e8e0d0]"}`} />
          </div>
          <span className={`text-xs mt-1 ${isActive("/profile") ? "text-[#9b7e4b]" : "text-[#e8e0d0]/70"}`}>
            Perfil
          </span>
        </Link>
      </div>
    </div>
  )
}
