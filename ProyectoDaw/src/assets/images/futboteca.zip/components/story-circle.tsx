import Image from "next/image"
import Link from "next/link"

interface StoryCircleProps {
  username: string
  avatar: string
  hasStory?: boolean
  isViewed?: boolean
}

export default function StoryCircle({ username, avatar, hasStory = false, isViewed = false }: StoryCircleProps) {
  return (
    <Link href={`/profile/${username}`} className="story-item">
      <div
        className={`relative ${
          hasStory ? (isViewed ? "avatar story border-[#9b7e4b]/30" : "avatar story border-[#d4af37]") : "avatar"
        }`}
      >
        <Image
          src={avatar || "/placeholder.svg"}
          alt={username}
          width={64}
          height={64}
          className="rounded-full object-cover"
        />
      </div>
      <span className="text-xs mt-1 text-center truncate max-w-[64px]">{username}</span>
    </Link>
  )
}
