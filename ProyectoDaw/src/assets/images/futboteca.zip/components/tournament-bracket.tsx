"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"

interface Match {
  id: number
  homeTeam: {
    id: number
    name: string
    logo: string
  }
  awayTeam: {
    id: number
    name: string
    logo: string
  }
  homeScore?: number
  awayScore?: number
  winner?: "home" | "away"
  matchUrl: string
}

interface Round {
  name: string
  matches: Match[]
}

interface TournamentBracketProps {
  rounds: Round[]
  title: string
  year: number
}

export default function TournamentBracket({ rounds, title, year }: TournamentBracketProps) {
  const [hoveredMatch, setHoveredMatch] = useState<number | null>(null)

  return (
    <div className="card p-6 animate-fade-in">
      <h2 className="text-xl font-bold mb-6 text-center">
        {title} {year}
      </h2>

      <div className="flex justify-between overflow-x-auto pb-4">
        {rounds.map((round, roundIndex) => (
          <div key={roundIndex} className="flex-shrink-0 w-64 px-2">
            <h3 className="text-center font-medium mb-4 text-[#9b7e4b]">{round.name}</h3>
            <div className="space-y-6">
              {round.matches.map((match, matchIndex) => (
                <Link
                  href={match.matchUrl}
                  key={match.id}
                  className={`block p-3 rounded-lg border transition-all ${
                    hoveredMatch === match.id
                      ? "border-[#9b7e4b] bg-[#9b7e4b]/10"
                      : "border-[#9b7e4b]/30 hover:border-[#9b7e4b]/60"
                  }`}
                  onMouseEnter={() => setHoveredMatch(match.id)}
                  onMouseLeave={() => setHoveredMatch(null)}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Image
                      src={match.homeTeam.logo || "/placeholder.svg?height=24&width=24"}
                      alt={match.homeTeam.name}
                      width={24}
                      height={24}
                      className="rounded-full"
                    />
                    <span
                      className={`flex-1 ${match.winner === "home" ? "font-bold text-[#d4af37]" : "text-[#e8e0d0]"}`}
                    >
                      {match.homeTeam.name}
                    </span>
                    <span className="font-medium">{match.homeScore !== undefined ? match.homeScore : "-"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Image
                      src={match.awayTeam.logo || "/placeholder.svg?height=24&width=24"}
                      alt={match.awayTeam.name}
                      width={24}
                      height={24}
                      className="rounded-full"
                    />
                    <span
                      className={`flex-1 ${match.winner === "away" ? "font-bold text-[#d4af37]" : "text-[#e8e0d0]"}`}
                    >
                      {match.awayTeam.name}
                    </span>
                    <span className="font-medium">{match.awayScore !== undefined ? match.awayScore : "-"}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
