"use client"

import { useState, useRef, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Era {
  id: string
  year: string
  title: string
}

interface EraSelectorProps {
  eras: Era[]
  activeEra: string
  onChange: (eraId: string) => void
}

export default function EraSelector({ eras, activeEra, onChange }: EraSelectorProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [showLeftArrow, setShowLeftArrow] = useState(false)
  const [showRightArrow, setShowRightArrow] = useState(true)

  useEffect(() => {
    const checkScroll = () => {
      if (!containerRef.current) return

      setShowLeftArrow(containerRef.current.scrollLeft > 0)
      setShowRightArrow(
        containerRef.current.scrollLeft < containerRef.current.scrollWidth - containerRef.current.clientWidth - 10,
      )
    }

    const container = containerRef.current
    if (container) {
      container.addEventListener("scroll", checkScroll)
      checkScroll()
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", checkScroll)
      }
    }
  }, [])

  const scrollLeft = () => {
    if (containerRef.current) {
      containerRef.current.scrollBy({ left: -200, behavior: "smooth" })
    }
  }

  const scrollRight = () => {
    if (containerRef.current) {
      containerRef.current.scrollBy({ left: 200, behavior: "smooth" })
    }
  }

  return (
    <div className="relative">
      {showLeftArrow && (
        <button
          onClick={scrollLeft}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 btn-icon bg-[#14100c]/80"
          aria-label="Desplazar a la izquierda"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
      )}

      <div ref={containerRef} className="era-selector px-4">
        {eras.map((era) => (
          <div
            key={era.id}
            className={`era-item ${activeEra === era.id ? "active" : ""}`}
            onClick={() => onChange(era.id)}
          >
            <div className="era-year">{era.year}</div>
            <div className="era-title">{era.title}</div>
          </div>
        ))}
      </div>

      {showRightArrow && (
        <button
          onClick={scrollRight}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 btn-icon bg-[#14100c]/80"
          aria-label="Desplazar a la derecha"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      )}
    </div>
  )
}
