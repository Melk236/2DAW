"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"

interface MatchTickerProps {
  matches: {
    id: number
    homeTeam: string
    homeTeamLogo: string
    awayTeam: string
    awayTeamLogo: string
    homeScore: number
    awayScore: number
    isLive?: boolean
    year: number
    tournament: string
    matchUrl: string
  }[]
}

export default function MatchTicker({ matches }: MatchTickerProps) {
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMatchIndex((prevIndex) => (prevIndex + 1) % matches.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [matches.length])

  const currentMatch = matches[currentMatchIndex]

  return (
    <Link href={currentMatch.matchUrl} className="block">
      <div className="match-ticker animate-fade-in">
        <div className="match-ticker-team">
          <Image
            src={currentMatch.homeTeamLogo || "/placeholder.svg?height=30&width=30"}
            alt={currentMatch.homeTeam}
            width={30}
            height={30}
            className="rounded-full"
          />
          <span className="font-medium">{currentMatch.homeTeam}</span>
        </div>
        <div className="match-ticker-score">
          {currentMatch.homeScore} - {currentMatch.awayScore}
        </div>
        <div className="match-ticker-team">
          <Image
            src={currentMatch.awayTeamLogo || "/placeholder.svg?height=30&width=30"}
            alt={currentMatch.awayTeam}
            width={30}
            height={30}
            className="rounded-full"
          />
          <span className="font-medium">{currentMatch.awayTeam}</span>
        </div>
        <div className="ml-auto text-sm text-[#e8e0d0]/70">
          {currentMatch.tournament} ({currentMatch.year})
        </div>
        {currentMatch.isLive && (
          <div className="match-ticker-live ml-4">
            <div className="match-ticker-live-dot"></div>
            <span>EN VIVO</span>
          </div>
        )}
      </div>
    </Link>
  )
}
