"use client"

import { useState } from "react"
import Image from "next/image"
import { Trophy, Award, Star, Calendar } from "lucide-react"

interface PlayerStats {
  name: string
  image: string
  stats: {
    goals: number
    assists: number
    matches: number
    trophies: number
    rating: number
  }
}

interface StatsComparisonProps {
  player1: PlayerStats
  player2: PlayerStats
}

export default function StatsComparison({ player1, player2 }: StatsComparisonProps) {
  const [activeTab, setActiveTab] = useState("stats")

  const getWinner = (stat1: number, stat2: number) => {
    if (stat1 > stat2) return "player1"
    if (stat2 > stat1) return "player2"
    return "tie"
  }

  return (
    <div className="card p-6 animate-fade-in">
      <h2 className="text-xl font-bold mb-6 text-center">Comparación de Leyendas</h2>

      <div className="flex justify-between items-center mb-8">
        <div className="text-center">
          <div className="relative w-24 h-24 mx-auto mb-2">
            <Image
              src={player1.image || "/placeholder.svg?height=96&width=96"}
              alt={player1.name}
              fill
              className="rounded-full object-cover border-2 border-[#9b7e4b]"
            />
          </div>
          <h3 className="font-bold">{player1.name}</h3>
        </div>

        <div className="text-2xl font-bold text-[#9b7e4b]">VS</div>

        <div className="text-center">
          <div className="relative w-24 h-24 mx-auto mb-2">
            <Image
              src={player2.image || "/placeholder.svg?height=96&width=96"}
              alt={player2.name}
              fill
              className="rounded-full object-cover border-2 border-[#9b7e4b]"
            />
          </div>
          <h3 className="font-bold">{player2.name}</h3>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center">
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player1.stats.goals, player2.stats.goals) === "player1" ? "text-[#d4af37]" : ""
            }`}
          >
            {player1.stats.goals}
          </div>
          <div className="w-10 flex justify-center">
            <Trophy className="h-5 w-5 text-[#9b7e4b]" />
          </div>
          <div className="flex-1 font-medium">Goles</div>
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player2.stats.goals, player1.stats.goals) === "player2" ? "text-[#d4af37]" : ""
            }`}
          >
            {player2.stats.goals}
          </div>
        </div>

        <div className="flex items-center">
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player1.stats.assists, player2.stats.assists) === "player1" ? "text-[#d4af37]" : ""
            }`}
          >
            {player1.stats.assists}
          </div>
          <div className="w-10 flex justify-center">
            <Award className="h-5 w-5 text-[#9b7e4b]" />
          </div>
          <div className="flex-1 font-medium">Asistencias</div>
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player2.stats.assists, player1.stats.assists) === "player2" ? "text-[#d4af37]" : ""
            }`}
          >
            {player2.stats.assists}
          </div>
        </div>

        <div className="flex items-center">
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player1.stats.matches, player2.stats.matches) === "player1" ? "text-[#d4af37]" : ""
            }`}
          >
            {player1.stats.matches}
          </div>
          <div className="w-10 flex justify-center">
            <Calendar className="h-5 w-5 text-[#9b7e4b]" />
          </div>
          <div className="flex-1 font-medium">Partidos</div>
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player2.stats.matches, player1.stats.matches) === "player2" ? "text-[#d4af37]" : ""
            }`}
          >
            {player2.stats.matches}
          </div>
        </div>

        <div className="flex items-center">
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player1.stats.trophies, player2.stats.trophies) === "player1" ? "text-[#d4af37]" : ""
            }`}
          >
            {player1.stats.trophies}
          </div>
          <div className="w-10 flex justify-center">
            <Trophy className="h-5 w-5 text-[#9b7e4b]" />
          </div>
          <div className="flex-1 font-medium">Trofeos</div>
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player2.stats.trophies, player1.stats.trophies) === "player2" ? "text-[#d4af37]" : ""
            }`}
          >
            {player2.stats.trophies}
          </div>
        </div>

        <div className="flex items-center">
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player1.stats.rating, player2.stats.rating) === "player1" ? "text-[#d4af37]" : ""
            }`}
          >
            {player1.stats.rating.toFixed(1)}
          </div>
          <div className="w-10 flex justify-center">
            <Star className="h-5 w-5 text-[#9b7e4b]" />
          </div>
          <div className="flex-1 font-medium">Valoración</div>
          <div
            className={`text-right flex-1 font-medium ${
              getWinner(player2.stats.rating, player1.stats.rating) === "player2" ? "text-[#d4af37]" : ""
            }`}
          >
            {player2.stats.rating.toFixed(1)}
          </div>
        </div>
      </div>

      <div className="mt-6 text-center">
        <button className="btn-primary">Ver comparación completa</button>
      </div>
    </div>
  )
}
