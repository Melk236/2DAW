"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { Search, Home, Compass, Upload, Bell, User, Menu, X, Trophy, Calendar } from "lucide-react"

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const pathname = usePathname()
  const [shouldRender, setShouldRender] = useState(true)

  // First useEffect - check if we should render
  useEffect(() => {
    setShouldRender(!(pathname === "/login" || pathname === "/register"))
  }, [pathname])

  // Second useEffect - handle scroll
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Skip navbar on login and register pages
  if (!shouldRender) {
    return null
  }

  // Check if link is active
  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "glass-effect py-2" : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-xl font-bold text-gradient">FUTBOTECA</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {/* Search Bar */}
            <div className={`relative transition-all duration-300 ease-in-out ${isSearchOpen ? "w-64" : "w-10"}`}>
              {isSearchOpen ? (
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Buscar videos, jugadores..."
                    className="w-full pl-10 pr-4 py-2 rounded-full bg-[#14100c] text-[#e8e0d0] border border-[#9b7e4b]/30 focus:outline-none focus:border-[#9b7e4b]"
                  />
                  <Search className="absolute left-3 top-2.5 h-4 w-4 text-[#e8e0d0]/60" />
                  <button
                    onClick={() => setIsSearchOpen(false)}
                    className="absolute right-3 top-2.5 text-[#e8e0d0]/60 hover:text-[#e8e0d0]"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsSearchOpen(true)}
                  className={`btn-icon ${isActive("/search") ? "active" : ""}`}
                >
                  <Search className="h-5 w-5" />
                </button>
              )}
            </div>

            {/* Navigation Links */}
            <Link href="/" className={`btn-icon ${isActive("/") ? "active" : ""}`}>
              <Home className="h-5 w-5" />
            </Link>
            <Link href="/explore" className={`btn-icon ${isActive("/explore") ? "active" : ""}`}>
              <Compass className="h-5 w-5" />
            </Link>
            <Link href="/eras" className={`btn-icon ${isActive("/eras") ? "active" : ""}`}>
              <Calendar className="h-5 w-5" />
            </Link>
            <Link href="/tournaments" className={`btn-icon ${isActive("/tournaments") ? "active" : ""}`}>
              <Trophy className="h-5 w-5" />
            </Link>
            <Link href="/upload" className={`btn-icon ${isActive("/upload") ? "active" : ""}`}>
              <Upload className="h-5 w-5" />
            </Link>
            <Link href="/notifications" className={`btn-icon ${isActive("/notifications") ? "active" : ""} relative`}>
              <Bell className="h-5 w-5" />
              <span className="badge">3</span>
            </Link>

            {/* User Avatar */}
            <Link href="/profile" className="ml-2">
              <div className={`avatar w-10 h-10 ${isActive("/profile") ? "ring-2 ring-[#9b7e4b]" : ""}`}>
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="User Avatar"
                  width={40}
                  height={40}
                  className="rounded-full object-cover"
                />
              </div>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-full hover:bg-[#9b7e4b]/20 text-[#e8e0d0]"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden glass-effect animate-fade-in">
          <div className="px-4 pt-2 pb-4 space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar videos, jugadores..."
                className="w-full pl-10 pr-4 py-2 rounded-full bg-[#14100c] text-[#e8e0d0] border border-[#9b7e4b]/30 focus:outline-none focus:border-[#9b7e4b]"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-[#e8e0d0]/60" />
            </div>

            <Link
              href="/"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Home className="h-5 w-5" />
              <span>Inicio</span>
            </Link>

            <Link
              href="/explore"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/explore") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Compass className="h-5 w-5" />
              <span>Explorar</span>
            </Link>

            <Link
              href="/eras"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/eras") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Calendar className="h-5 w-5" />
              <span>Épocas</span>
            </Link>

            <Link
              href="/tournaments"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/tournaments") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Trophy className="h-5 w-5" />
              <span>Torneos</span>
            </Link>

            <Link
              href="/upload"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/upload") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Upload className="h-5 w-5" />
              <span>Subir Video</span>
            </Link>

            <Link
              href="/notifications"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/notifications") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <Bell className="h-5 w-5" />
              <span>Notificaciones</span>
              <span className="ml-auto bg-[#d4af37] text-[#14100c] px-2 py-0.5 rounded-full text-xs font-bold">3</span>
            </Link>

            <Link
              href="/profile"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg ${
                isActive("/profile") ? "bg-[#9b7e4b]/20 text-[#9b7e4b]" : "text-[#e8e0d0]"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              <User className="h-5 w-5" />
              <span>Mi Perfil</span>
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}
